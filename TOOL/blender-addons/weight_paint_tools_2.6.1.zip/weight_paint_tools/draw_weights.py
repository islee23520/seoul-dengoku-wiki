# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

# TODO: skip mesh topo refreshing. Only weights will change
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent
import numpy as np
from functools import cache
from .wpt_helpers import get_mirrored_name, get_addon_preferences

VERTICES = None
FACES_BATCH = None
EDGES_BATCH = None
VERTS_BATCH_SELECTED = None
VERTS_BATCH_UNSELECTED = None
# shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')
shader_smooth = gpu.shader.from_builtin('SMOOTH_COLOR')
line_shader_smooth = gpu.shader.from_builtin('POLYLINE_SMOOTH_COLOR') if bpy.app.version >= (4, 5, 0) else shader_smooth

shader_uniform = gpu.shader.from_builtin('UNIFORM_COLOR')
point_shader = gpu.shader.from_builtin('POINT_UNIFORM_COLOR') if bpy.app.version >= (4, 5, 0) else shader_uniform


theme = bpy.context.preferences.themes['Default']
g_vertex_color = theme.view_3d.vertex
g_vertex_sel_color = theme.view_3d.vertex_select
g_wire_edit_color = theme.view_3d.wire_edit
g_edge_sel_color = theme.view_3d.edge_select

def depth_offset_matrix_method(obj_mw, dynamic_depth_off):
    # bgl.glDepthRange(0, maxRange) # XXX: breaks colors alpha in B3.5
    winmat = gpu.matrix.get_projection_matrix()
    # winmat[3][2] -= 0.1*dynamic_depth_off  # bias toward camera offset -- simple ver

    # bias toward cam - adv version
    is_persp = winmat[3][3] == 0.0
    win_23 = winmat[2][3]
    win_22 = winmat[2][2]
    if is_persp:
        near = win_23 / (win_22 - 1.0)
        far = win_23 / (win_22 + 1.0)
    else:
        near = (win_23 + 1.0) / win_22
        far = (win_23 - 1.0) / win_22

    far += dynamic_depth_off
    near += dynamic_depth_off
    range = far - near
    if is_persp:
        winmat[2][2] = -(far + near) / range
        winmat[2][3] = (-2 * far * near) / range
    else:
        winmat[2][3] = -(far + near) / range

    gpu.matrix.multiply_matrix(obj_mw)
    gpu.matrix.push_projection()
    gpu.matrix.load_projection_matrix(winmat)

def calc_depth_offset(context) -> None: # for nice strand overlay drawing
    view3d = context.space_data
    average_co = view3d.region_3d.view_location # seems ok

    camera_pos = context.region_data.view_matrix.inverted().translation
    camDistance = camera_pos - average_co
    cam_dist = camDistance.length
    if cam_dist > 1e-6:
        camDistance = cam_dist
    else: # mostly for  for ortho view. prevent division by zero
        camDistance = 1.0

    draw_weights_overlay = bpy.context.scene.draw_weights_overlay
    viewport_clip = 0.05 * context.space_data.clip_start
    dynamic_depth_off = viewport_clip * draw_weights_overlay.draw_offset / camDistance
    # dynamic_depth_off = addon_prefs.draw_offset / camDistance.length_squared
    return dynamic_depth_off

def draw_colors_px(self, context):
    obj = bpy.context.active_object
    if obj is None or obj.type != 'MESH' or not FACES_BATCH: # and obj.mode == "WEIGHT_PAINT"
        return
    theme = bpy.context.preferences.themes['Default']
    g_vertex_size = theme.view_3d.vertex_size

    dynamic_depth_off = 1.1*calc_depth_offset(context)  # scene_ht.higlight_bias) - bring closer 10% to cam - to avoid z-fighting with 'strands overlay'

    gpu.state.blend_set("ALPHA")
    if bpy.app.version >= (4, 5, 0):
        line_shader_smooth.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
        line_shader_smooth.uniform_float("lineWidth", 2.0)
    else:
        gpu.state.line_width_set(2.0)
    gpu.state.point_size_set(g_vertex_size+1)
    gpu.state.face_culling_set("BACK")
    # gpu.state.depth_mask_set(True)
    gpu.state.depth_test_set("LESS_EQUAL")
    with gpu.matrix.push_pop(): # or else obj.mw may be applied twice, if other draw handler is active with matrix.multiply ...
        depth_offset_matrix_method(obj.matrix_world, dynamic_depth_off) # dynamic_depth_off=0.001
        # bgl.glDepthRange(0.0, 0.9999)
        # bgl.glEnable(bgl.GL_POLYGON_OFFSET_FILL)
        # bgl.glPolygonOffset(-5.0, 0.0)
        # bpy.data.meshes.remove(mesh)
        shader_smooth.bind()
        FACES_BATCH.draw(shader_smooth)
        if context.active_object.data.use_paint_mask_vertex:
            if VERTS_BATCH_SELECTED is not None:
                sel_color = (g_vertex_sel_color.r, g_vertex_sel_color.g, g_vertex_sel_color.b, 1.0) #  g_vertex_sel_color[:] wont work
                point_shader.uniform_float("color", sel_color)
                VERTS_BATCH_SELECTED.draw(point_shader)
            if VERTS_BATCH_UNSELECTED is not None:
                vert_color = (g_vertex_color.r, g_vertex_color.g, g_vertex_color.b, 1.0) # g_vertex_color[:] wont work..
                point_shader.uniform_float("color", vert_color)
                VERTS_BATCH_UNSELECTED.draw(point_shader)
        # EDGES_BATCH.draw(line_shader_smooth)
        # BATCH_EDGES.draw(shader) #z fight. Probably have to write new shader??
        # restore opengl defaults
        # bgl.glDisable(bgl.GL_POLYGON_OFFSET_FILL)
        # bgl.glDepthRange(0.0, 1.0)
        gpu.matrix.pop_projection()

    # hack replaces GL_POLYGON_OFFSET_FILL - to prevent edges from z-fighting/clipping through faces
    with gpu.matrix.push_pop(): # or else obj.mw may be applied twice, if other draw handler is active with matrix.multiply ...
        depth_offset_matrix_method(obj.matrix_world, dynamic_depth_off*1.05) # dynamic_depth_off=0.001
        EDGES_BATCH.draw(line_shader_smooth)
        gpu.matrix.pop_projection()

    gpu.state.face_culling_set("NONE")
    gpu.state.depth_test_set("NONE")
    # if bpy.app.version >= (4, 5, 0):
    #     line_shader_smooth.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    #     line_shader_smooth.uniform_float("lineWidth", 1.0)
    # else:
    #     gpu.state.line_width_set(1.0)
    gpu.state.point_size_set(1)


def DrawWeightsPanel(self, context):
    if context.active_object and context.active_object.type == 'MESH':
        draw_weights_overlay = context.scene.draw_weights_overlay
        box = self.layout.box()
        col = box.column()
        col.prop(draw_weights_overlay, "enable_draw_weights", toggle=True)
        if draw_weights_overlay.enable_draw_weights:
            col.prop(draw_weights_overlay, "merge_r_l_color", toggle=True)
            split = col.split(factor=0.7)
            split.prop(draw_weights_overlay, "polygonOpacity")
            split.prop(draw_weights_overlay, "seed")
            col.prop(draw_weights_overlay, "draw_offset")


handle_SpaceView3D = None


@persistent
def sd_scene_update(scene, depsgraph):
    build_obj_cache(depsgraph)

FORCE_UPDATE = False

@persistent
def LoadPostDisableDrawWeights(scn):
    # handle_handlers_draw_weights()
    #since it dosent work anyway on scene load. Plus prevets Draw Xray from running in background
    bpy.context.scene.draw_weights_overlay.enable_draw_weights = False


def handle_handlers_draw_weights():
    global handle_SpaceView3D
    draw_weights_overlay = bpy.context.scene.draw_weights_overlay
    drawWeights = draw_weights_overlay.enable_draw_weights

    if drawWeights:
        # Generate colors once and cache
        seed = draw_weights_overlay.seed
        np.random.seed(seed=seed)
        rand_colors = np.random.random((250, 3)).astype(np.float32)
        # Normalize colors efficiently
        norms = np.linalg.norm(rand_colors, axis=1, keepdims=True)
        rand_colors /= norms
        bpy.types.Scene.rand_colors = rand_colors

        if handle_SpaceView3D is None:
            args = (DrawWeightsPropG, bpy.context)
            handle_SpaceView3D = bpy.types.SpaceView3D.draw_handler_add(draw_colors_px, args, 'WINDOW', 'POST_VIEW')

        if sd_scene_update not in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.append(sd_scene_update)
    else:
        if handle_SpaceView3D is not None:
            bpy.types.SpaceView3D.draw_handler_remove(handle_SpaceView3D, 'WINDOW')
            handle_SpaceView3D = None

        if sd_scene_update in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(sd_scene_update)



class DrawWeightsPropG(bpy.types.PropertyGroup):
    def DrawMeshUpdate(self, context):
        setup_cols.cache_clear() # clear functools cache
        handle_handlers_draw_weights()
        if context.active_object and context.active_object.type == 'MESH':
            build_obj_cache(context.evaluated_depsgraph_get())
            context.active_object.data.update_tag()

    enable_draw_weights: bpy.props.BoolProperty(name="Draw Weights", description="Draw Weights", default=False, update=DrawMeshUpdate)
    merge_r_l_color: bpy.props.BoolProperty(name="Merge Colors", description="Merge Colors from right side to left", default=True, update=DrawMeshUpdate)
    seed: bpy.props.IntProperty(name="seed", description="Color seed", min=0, max=20, default=1, update=DrawMeshUpdate)
    polygonOpacity: bpy.props.FloatProperty(name="polygon color opacity", description="polygon color opacity", min=0.0, max=1.0, default=0.9, subtype='PERCENTAGE', update=DrawMeshUpdate)
    draw_offset: bpy.props.FloatProperty(name="Draw Offset", description="Strand Draw Offset (similar to Draw In Front option in Blender)", min=0.0, soft_max=1.0, default=0.1, subtype='FACTOR')


# create addon prefereces
# class DrawWeightsPreferences(bpy.types.AddonPreferences):
#     bl_idname = __name__
#
#     def DrawMeshUpdate(self, context):
#         calculate_weights(bpy.context.evaluated_depsgraph_get())
#
#
#     colorize_active_group: bpy.props.BoolProperty(name="Colorize Active Group", description="Colorize Active Group", default=True, update=DrawMeshUpdate)
#     active_group_color: bpy.props.FloatVectorProperty(name="Active Group Color", description="Active Group Color", default=g_vertex_sel_color, min=0.0, max=1.0, subtype='COLOR', size=3, update=DrawMeshUpdate)
#
#     def draw(self, context):
#         layout = self.layout
#         layout.prop(self, "colorize_active_group", toggle=True)
#         if self.colorize_active_group:
#             layout.prop(self, "active_group_color")


# def get_mirrored_name(name):
#     if len(name) > 2 and (name[-2] == '.' or name[-2] == '_'):
#         if name[-1] == 'l':
#             return name[:-1]+'r'
#         elif name[-1] == 'r':
#             return name[:-1]+'l'
#         elif name[-1] == 'L':
#             return name[:-1]+'R'
#         elif name[-1] == 'R':
#             return name[:-1]+'L'
#         else:
#             return ''
#     else:
#         return ''



@cache
def setup_cols(active_obj, vg_cnt):
    # print('setup_cols')
    groups_color_idx = [1]*len(active_obj.vertex_groups)
    if bpy.context.scene.draw_weights_overlay.merge_r_l_color:
        for i, group in enumerate(active_obj.vertex_groups):
            mirrored_vg_name = get_mirrored_name(group.name)
            if mirrored_vg_name in active_obj.vertex_groups.keys():
                mirrored_g_idx = active_obj.vertex_groups[mirrored_vg_name].index
                groups_color_idx[i] = int((group.index + mirrored_g_idx) / 2)
            else:
                groups_color_idx[i] = i
    else:
        for i, group in enumerate(active_obj.vertex_groups):
            groups_color_idx[i] = i
    return groups_color_idx


def calculate_weights(depsgraph):
    active_obj = bpy.context.active_object
    global FACES_BATCH, EDGES_BATCH, VERTS_BATCH_SELECTED,VERTS_BATCH_UNSELECTED, FORCE_UPDATE
    FORCE_UPDATE = False

    obj_eval = active_obj.evaluated_get(depsgraph)
    mesh = obj_eval.to_mesh()

    vert_count = len(mesh.vertices)
    if vert_count != len(active_obj.data.vertices):  # probably modifier adds/removes verts. Can draw mesh like that
        FACES_BATCH = None
        return

    groups_color_idx = setup_cols(active_obj, len(active_obj.vertex_groups))

    # Cache frequently accessed objects
    addon_prefs = get_addon_preferences()
    rand_colors = bpy.context.scene.rand_colors
    draw_weights_overlay = bpy.context.scene.draw_weights_overlay
    vertex_groups = active_obj.vertex_groups
    active_group_idx = vertex_groups.active_index

    # Pre-allocate vertex colors array
    vert_weights_col = np.zeros((vert_count, 3), dtype='f')

    # Optimize vertex group weight calculation
    colorize_active = addon_prefs.colorize_active_group
    active_color = addon_prefs.active_group_color

    # Build vertex group data arrays for vectorization
    vertex_indices = []
    group_indices = []
    weights = []

    for vert in mesh.vertices:
        for g in vert.groups:
            if not vertex_groups[g.group].lock_weight:
                vertex_indices.append(vert.index)
                group_indices.append(g.group)
                weights.append(g.weight)

    if vertex_indices:  # Only process if we have data
        vertex_indices = np.array(vertex_indices)
        group_indices = np.array(group_indices)
        weights = np.array(weights)

        # Vectorized color selection
        is_active = (group_indices == active_group_idx) & colorize_active
        color_indices = np.where(is_active, -1, np.array([groups_color_idx[g] for g in group_indices]))

        # Apply colors vectorized
        for (v_idx, weight, color_idx, is_act) in zip(vertex_indices, weights, color_indices, is_active):
            color = active_color if is_act else rand_colors[color_idx]
            vert_weights_col[v_idx] += weight * color

    mesh.calc_loop_triangles()
    loop_triangles_count = len(mesh.loop_triangles)

    global VERTICES, INDICES
    if VERTICES is None or vert_count != VERTICES.shape[0]:
        print('init vert')
        VERTICES = np.empty((vert_count, 3), 'f')
        INDICES = np.empty((loop_triangles_count, 3), 'i')
        mesh.loop_triangles.foreach_get("vertices", INDICES.ravel())

    mesh.vertices.foreach_get("co", VERTICES.ravel())


    # Pre-compute boolean arrays once
    hidden_verts = np.array([vert.hide for vert in mesh.vertices], dtype=bool)
    selected_verts = np.array([vert.select for vert in mesh.vertices], dtype=bool)

    # Optimized color array creation
    polygon_opacity = draw_weights_overlay.polygonOpacity
    alpha_channel = np.where(hidden_verts, 0.0, polygon_opacity)

    vert_colors = np.column_stack([vert_weights_col, alpha_channel])

    # Pre-create color arrays as numpy arrays
    edge_base_color = np.array([g_wire_edit_color.r, g_wire_edit_color.g, g_wire_edit_color.b, 0.7], dtype='f')
    edge_sel_color = np.array([g_edge_sel_color.r, g_edge_sel_color.g, g_edge_sel_color.b, 0.7], dtype='f')
    # vert_base_color = np.array([g_vertex_color.r, g_vertex_color.g, g_vertex_color.b, 1.0], dtype='f')
    # vert_sel_color = np.array([g_vertex_sel_color.r, g_vertex_sel_color.g, g_vertex_sel_color.b, 1.0], dtype='f')

    # Efficient color assignment using broadcasting
    edge_col = np.tile(edge_base_color, (vert_count, 1))
    edge_col[selected_verts] = edge_sel_color

    # vert_col = np.tile(vert_base_color, (vert_count, 1))
    # vert_col[selected_verts] = vert_sel_color

    # Convert to list format for batch_for_shader
    v_col = vert_colors.tolist()   # for shader we need list
    edge_col = edge_col.tolist()
    # vert_col = vert_col.tolist()

    world_verts = VERTICES  # obj.mw - handled by gpu matrix now
    FACES_BATCH = batch_for_shader(shader_smooth, 'TRIS', {"pos": world_verts, "color": v_col}, indices=INDICES)
    EDGES_BATCH = batch_for_shader(line_shader_smooth, 'LINES', {"pos": world_verts, "color": edge_col}, indices=mesh.edge_keys)

    # Create position arrays for each batch
    VERTS_BATCH_SELECTED = None
    VERTS_BATCH_UNSELECTED = None
    if bpy.context.active_object.data.use_paint_mask_vertex:
        # Get indices of selected and unselected vertices
        selected_indices = np.where(selected_verts)[0]
        unselected_indices = np.where(~selected_verts)[0]

        if len(selected_indices) > 0:
            selected_positions = VERTICES[selected_indices][:]
            VERTS_BATCH_SELECTED = batch_for_shader(point_shader, 'POINTS', {"pos": selected_positions})


        if len(unselected_indices) > 0:
            unselected_positions = VERTICES[unselected_indices][:]
            VERTS_BATCH_UNSELECTED = batch_for_shader(point_shader, 'POINTS', {"pos": unselected_positions})

    obj_eval.to_mesh_clear()

def build_obj_cache(depsgraph):
    active_obj = bpy.context.active_object
    if bpy.context.scene.draw_weights_overlay.enable_draw_weights:
        if active_obj and active_obj.type == 'MESH': # and active_obj.mode == 'WEIGHT_PAINT':
            if FORCE_UPDATE:
                calculate_weights(depsgraph)
                return
            # strands_points.append(np.einsum('ij,aj->ai', mat, points_to_vec)) #mat times point list
            if hasattr(depsgraph,'updates'):
                for update in depsgraph.updates:
                    # print((f'ID {update.id}, geom {update.is_updated_geometry}, xform {update.is_updated_transform}'))
                    if (update.id.original == active_obj and (update.is_updated_geometry or update.is_updated_transform)) or FORCE_UPDATE:
                        calculate_weights(depsgraph)
                        return


def register_wp():
    # bpy.utils.register_class(DrawWeightsPreferences)
    # bpy.utils.register_class(DrawWeightsPropG)
    bpy.types.VIEW3D_PT_overlay.append(DrawWeightsPanel)
    bpy.types.Scene.rand_colors = {}
    bpy.types.Scene.draw_weights_overlay = bpy.props.PointerProperty(type=DrawWeightsPropG)
    bpy.app.handlers.load_post.append(LoadPostDisableDrawWeights)


def unregister_wp():
    global handle_SpaceView3D
    if handle_SpaceView3D is not None:
        bpy.types.SpaceView3D.draw_handler_remove(handle_SpaceView3D, 'WINDOW')
        handle_SpaceView3D = None

    if sd_scene_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(sd_scene_update)

    bpy.app.handlers.load_post.remove(LoadPostDisableDrawWeights)

    bpy.context.scene.draw_weights_overlay.enable_draw_weights = False  # TO hide draw xray on F8 reload
    # bpy.utils.unregister_class(DrawWeightsPreferences)
    # bpy.utils.unregister_class(DrawWeightsPropG)
    bpy.types.VIEW3D_PT_overlay.remove(DrawWeightsPanel)

    del bpy.types.Scene.draw_weights_overlay
    del bpy.types.Scene.rand_colors


# if __name__ == "__main__":
#     register()

