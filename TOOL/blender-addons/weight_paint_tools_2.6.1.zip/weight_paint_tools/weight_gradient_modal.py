'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO
Thanks to Jaroslaw Cwik for Ideas on aligning curves tilt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy
import bmesh  # for random color to mesh islands
from mathutils import Vector, Matrix
from mathutils import Vector
from .wpt_helpers import *
from .screen_drawing.view_drawing import GlDrawing
from .weight_paint_tool import WPT_OT_MirrorVG

# for gradient tool
from bpy_extras import view3d_utils
import gpu
import math

grad_times = (('EASE', 'Ease in/out', ''),
              ('LINEAR', 'Linear', ''),
              ('GAUSSIAN', 'Gaussian', ''))

mix_items = (('REPLACE',"Replace",""),('ADD',"Add",""),('SUBTRACT',"Subtract",""))

# This function from a script by Bartosz Styperek
class WPT_OT_DrawWeightGradient(bpy.types.Operator, GlDrawing):
    """Draw a line with the mouse to paint a vertex color gradient."""
    bl_idname = "paint.draw_weight_gradient"
    bl_label = "Draw Gradient"
    bl_description = "Draw Weight Gradient - Default hotkey ctrl+D"
    bl_options = {"REGISTER", "UNDO"}

    _handle_draw_line = None
    _handleUI = None
    startPoint = None
    endPoint = None
    lmb_clicked = False
    drawing_gradient_finished = False

    gradient_type: bpy.props.EnumProperty(name="Gradient Type", default="GAUSSIAN", items=grad_times)
    gradient_type_loop= EnumListLoop(grad_times, default='GAUSSIAN')

    gradient_fallof: bpy.props.FloatProperty(name="Gradient falloff", description="Gradient falloff", default=0,
                                              min=-1, max=1, subtype='PERCENTAGE')
    mix_method: bpy.props.EnumProperty(
        name="Mix method",
        items=mix_items,
        default='REPLACE',
        description="Mix method"
    )
    mix_method_index_cycles = EnumListLoop(mix_items)

    def text_lines_data(self, context):
        lines = []
        if bpy.app.version < (5, 0, 0):
            weight = context.scene.tool_settings.unified_paint_settings.weight
        else:
            weight = context.scene.tool_settings.weight_paint.unified_paint_settings.weight
        lines.append([f"[MMB]Weight: {round(weight,3)}", 'p'])
        grad_str = ' '.join([f'[{m[0]}]' if m[0]==self.gradient_type else m[0] for m in grad_times])
        lines.append([f"[G]radient Type: {grad_str}", 'p'])
        lines.append([f"[MMB+Shift] Fallof: {round(self.gradient_fallof, 1)}", 'p'])

        mix_m = ' '.join([f'[{m[0]}]' if m[0]==self.mix_method else m[0] for m in mix_items])
        lines.append([f"[M]ix method: {mix_m}", 'p'])
        return lines

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def draw_lig_grad_ui_callback(self, context):
        self._handleUI = self.draw_text_lines(context, self.text_lines_data, draw_as='UI')


    def line_data(self):
        '''For dynamic generation on draw lines data '''
        return ((int(self.startPoint.x), int(self.startPoint.y)), (int(self.endPoint.x), int(self.endPoint.y)))

    def draw_line(self, context):
        self.draw_color = (1, 1, 1, 1)
        self._handle_draw_line = self.draw_lines(self.line_data, mode='2D', draw_as='UI')  # data_id = 'lines', passed by reference to parent class. self.draw_cache['lines']


    def draw_gradient_weight(self, context):

        region = context.region
        rv3d = context.region_data

        obj = context.active_object
        # mesh = obj.data
        target_id = obj.vertex_groups.active_index

        downVec = Vector((0, -1, 0))
        drawnVec = Vector((self.endPoint.x-self.startPoint.x, self.endPoint.y-self.startPoint.y, 0)).normalized()
        rotQuat = drawnVec.rotation_difference(downVec)
        translationMatrix = Matrix.Translation(Vector((-self.startPoint.x, -self.startPoint.y, 0)))

        combinedMat = translationMatrix.inverted() @ rotQuat.to_matrix().to_4x4() @ translationMatrix

        trans_start = combinedMat @ self.startPoint.to_4d()  # transform drawn line : rotate it to align to horizontal line
        trans_end = combinedMat @ self.endPoint.to_4d()
        min_y = trans_start.y
        max_y = trans_end.y
        height_trans = max_y - min_y  # get the height of transformed vector

        if self.gradient_type == 'EASE':
            cpow = calc_power(self.gradient_fallof)
        # No setup needed for LINEAR

        if bpy.app.version < (5, 0, 0):
            current_weight = context.scene.tool_settings.unified_paint_settings.weight
        else:
            current_weight = context.scene.tool_settings.weight_paint.unified_paint_settings.weight
        for i, data in enumerate(self.vertex_data):
            if data[1] is None:
                continue
            vertex_id = data[0]
            vertCo4d = Vector((data[1].x, data[1].y, 0))
            transVec = combinedMat @ vertCo4d

            factor = abs(max(min((transVec.y - min_y) / height_trans, 1), 0)) if height_trans != 0 else 1

            if self.gradient_type == 'EASE':
                factor = math.pow(factor, cpow)
            elif self.gradient_type == 'GAUSSIAN':
                factor = easing_cubic_ease_in_out(factor)*(self.gradient_fallof+1)/2 + factor * (1/2 - self.gradient_fallof/2)
            elif self.gradient_type == 'LINEAR':
                # Linear interpolation, optionally apply falloff as a slope
                pass


            if self.mix_method=='REPLACE':
                obj.vertex_groups[target_id].add([vertex_id], (1-factor)*self.old_weight[i] + factor * current_weight, "REPLACE")
            elif self.mix_method == 'ADD':
                obj.vertex_groups[target_id].add([vertex_id], self.old_weight[i] + factor * current_weight,  "REPLACE")
            else:
                obj.vertex_groups[target_id].add([vertex_id], self.old_weight[i] - factor * current_weight,  "REPLACE")

        # symm = not is_name_r_l(context.active_object.vertex_groups.active.name)
        WPT_OT_MirrorVG.vg_mirror(context, obj, self.kd)

        # context.active_object.data.update()
        # if has_armature(context.object):
        # bpy.ops.object.weight_normalize_with_symmetry('INVOKE_DEFAULT',group_select_mode= self.normalize_select_mode, lock_active=self.normalize_lock)
        # bpy.ops.object.weight_normalize_with_symmetry('INVOKE_DEFAULT')

        # obj.data.update()

    def axis_snap(self, start, end, delta):
        if start.x - delta < end.x < start.x + delta:
            return Vector((start.x, end.y))
        if start.y - delta < end.y < start.y + delta:
            return Vector((end.x, start.y))
        return end

    def modal(self, context, event):
        context.area.tag_redraw()
        mesh = context.active_object.data
        delta = 20
        if event.type == 'MOUSEMOVE' and self.lmb_clicked == True and not self.drawing_gradient_finished:
            self.endPoint = Vector((event.mouse_region_x, event.mouse_region_y))
            if event.shift:
                self.endPoint = self.axis_snap(self.startPoint, self.endPoint, delta)
            self.draw_gradient_weight(context)

        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE' and not self.drawing_gradient_finished:  # finish drawing box, and calculate uv Transformation
            self.endPoint = Vector((event.mouse_region_x, event.mouse_region_y))
            if event.shift:
                self.endPoint = self.axis_snap(self.startPoint, self.endPoint, delta)
            self.disable_handler(self._handle_draw_line)
            self._handle_draw_line = None

            if not self._handleUI:
                self.draw_lig_grad_ui_callback(context)

            self.draw_gradient_weight(context)

            self.drawing_gradient_finished = True
            # return {'FINISHED'}

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not self.drawing_gradient_finished:
            self.startPoint = Vector((event.mouse_region_x, event.mouse_region_y))
            self.endPoint = self.startPoint+Vector((1, 1))  # To prevent drawing line to random place

            if not self._handle_draw_line:
                self.draw_line(context)

            self.lmb_clicked = True

        elif event.type =='M' and event.value == 'PRESS':
            self.mix_method = self.mix_method_index_cycles.next()
            self.draw_gradient_weight(context)

        elif (event.type in ('WHEELUPMOUSE','PAGE_UP') and event.value == 'PRESS') and not event.shift:
            if bpy.app.version < (5, 0, 0):
                context.scene.tool_settings.unified_paint_settings.weight += 0.1
            else:
                context.scene.tool_settings.weight_paint.unified_paint_settings.weight += 0.1
            self.draw_gradient_weight(context)

        elif (event.type in ('WHEELDOWNMOUSE','PAGE_DOWN') and event.value == 'PRESS') and not event.shift:
            if bpy.app.version < (5, 0, 0):
                context.scene.tool_settings.unified_paint_settings.weight -= 0.1
            else:
                context.scene.tool_settings.weight_paint.unified_paint_settings.weight -= 0.1
            self.draw_gradient_weight(context)

        elif (event.type in ('WHEELUPMOUSE','PAGE_UP')  and event.value == 'PRESS') and event.shift:
            self.gradient_fallof += 0.1
            self.draw_gradient_weight(context)

        elif (event.type in ('WHEELDOWNMOUSE','PAGE_DOWN') and event.value == 'PRESS') and event.shift:
            self.gradient_fallof -= 0.1
            self.draw_gradient_weight(context)

        elif event.type == "G" and event.value == 'PRESS':
            self.gradient_type = self.gradient_type_loop.next()
            self.draw_gradient_weight(context)

        elif event.type in {'ESC',}:
            self.report({'INFO'}, 'CANCELLED')
            self.disable_handlers()
            bpy.ops.ed.undo()
            return {'CANCELLED'}

        elif event.type in {'RET', 'MIDDLEMOUSE', 'RIGHTMOUSE'} or (event.type == 'LEFTMOUSE' and self.drawing_gradient_finished):
            self.report({'INFO'}, 'FINISHED')
            self.disable_handlers()
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            bpy.ops.ed.undo_push()
            self.old_weight = []
            mesh = context.active_object.data
            target_id = context.active_object.vertex_groups.active_index
            # create_weights_cache(context.object)
            if context.object.data.use_paint_mask_vertex or context.object.data.use_paint_mask:  # Face masking not currently supported here
                verts = [v for v in mesh.vertices if v.select]
            else:
                verts = [v for v in mesh.vertices]
            for vert in verts:
                vert_weight = [group.weight for group in vert.groups if group.group == target_id]
                self.old_weight.append(0 if len(vert_weight) == 0 else vert_weight[0])

            obj = context.active_object
            self.kd = build_mesh_kd_tree(obj.data)

            deform_mods = {"ARMATURE", "CORRECTIVE_SMOOTH", "SMOOTH", "SHRINKWRAP", "SIMPLE_DEFORM", "LATTICE"}
            mod_state = []
            for mod in obj.modifiers:  # disable modifiers
                if mod.type not in deform_mods:
                    mod_state.append(mod.show_viewport)
                    mod.show_viewport = False

            depsgraph = context.evaluated_depsgraph_get()
            object_eval = obj.evaluated_get(depsgraph)
            target_id = obj.vertex_groups.active_index

            if target_id == -1:
                bpy.ops.object.vertex_group_add()
                target_id = obj.vertex_groups.active_index

            region = context.region
            rv3d = context.region_data
            # List of structures containing 3d vertex and project 2d position of vertex
            self.vertex_data = None  # will contain vert, and vert coordinates in 2d view space

            if context.object.data.use_paint_mask_vertex or context.object.data.use_paint_mask:  # Face masking not currently supported here
                self.vertex_data = [(v.index, view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v.co)) for v in object_eval.data.vertices if v.select]
            else:
                self.vertex_data = [(v.index, view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v.co)) for v in object_eval.data.vertices]
            # rv3d.perspective_matrix.translation  += 10@vec_from_cam_to_origin
            for mod in obj.modifiers:
                if mod.type not in deform_mods:
                    mod.show_viewport = mod_state.pop()
            bpy.ops.ed.undo_push() # avoid undoung step before calling grad draw
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}
