'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy
import bmesh

from mathutils import Vector
from mathutils.bvhtree import BVHTree
from itertools import cycle
from .wpt_helpers import *
from .screen_drawing.view_drawing import GlDrawing


label_to_clean = {
    'ALL':"All Groups",
    'ACTIVE': "Active Bone",
    'BONE_SELECT': "Selected Bones",
    'BONE_DEFORM': "Deformer Bones",
    'DISABLED': "Disabled"
}

NORMALIZE_MSG = None
NORMALIZE_ITEMS = []  # for keeping reference in python to items - fix enum bug in blender
def normalize_items(self, context):
    # arma_obj = get_armature_from_active_bone(context, context.object)
    assigned_active_armatures = [mod.object for mod in context.active_object.modifiers if mod.type=='ARMATURE' and mod.show_viewport and mod.object]
    if not assigned_active_armatures:
        items = [('ALL', "ALL", ""),
            ('DISABLED', "DISABLED", "")]
    else:
        items = [('ALL', "ALL", ""),
            ('BONE_DEFORM', "BONE_DEFORM", ""),
            # ('BONE_SELECT', "BONE_SELECT", ""),
            ('DISABLED', "DISABLED", "")]
    global NORMALIZE_ITEMS
    if items != NORMALIZE_ITEMS:  # for  now this seems to fix random changes....
        NORMALIZE_ITEMS = items
    return NORMALIZE_ITEMS

TARGET_ITEMS = []  # for keeping reference in python to items - fix enum bug in blender
def target_items(self, context):
    sel_arma = [mod.object for mod in context.active_object.modifiers if mod.type=='ARMATURE' and mod.show_viewport and mod.object]
    if sel_arma:
        items = (('ALL', "All Groups", ""),
                ('ACTIVE', "Active Group", ""),
                ('BONE_SELECT', "Selected Bones", ""),
                ('BONE_DEFORM', "Deformer Bones", ""))
    else:
        items = (('ALL', "All Groups", ""),
                ('ACTIVE', "Active Bone", ""))
    global TARGET_ITEMS
    if items != TARGET_ITEMS:  # for  now this seems to fix random changes....
        TARGET_ITEMS = items
    return TARGET_ITEMS

mix_items = (('REPLACE',"Replace",""),('ADD',"Add",""),('SUBTRACT',"Subtract",""))
class WPT_OT_WeightSet(bpy.types.Operator, OperatorSettings, GlDrawing):
    bl_idname = "paint.weight_set_wp"
    bl_label = "Set Weight"
    bl_description = "Set selected vertices weights \n" \
                    "Scroll MMB: +/- 0.1 to vertex weight \n" \
                    "Scroll MMB + Shift: +/- 0.05 to vertex weight \n" \
                    "N: Normalize result - (make sum of all vertex weights == 1)\n" \
                    "LMB or Enter to accept \n" \
                    "RMB or ESC to cancel"

    bl_options =  {"REGISTER", 'UNDO'}

    weight: bpy.props.FloatProperty(default=0.0,name="Weight", description="Weight to set", min=-1.0, max=1.0, options={'SKIP_SAVE'})
    # normalize: bpy.props.BoolProperty(default=True,name="Normalize", description="Normalize result (make sum of all weights 1)")
    mix_method: bpy.props.EnumProperty( name="Mix method", items = mix_items, default='REPLACE', description="Mix method")
    mix_method_index_cycles = EnumListLoop(mix_items)
    normalize_select_mode: bpy.props.EnumProperty(
        name="Normalize",
        items=normalize_items,
        description="Normalize result (make sum of all weights 1)"
    )
    lock_active: bpy.props.BoolProperty(default=True, name="Lock Active", description="Lock Activee vertex group while normalizing")

    @classmethod
    def poll(cls, context):
        return context.active_object

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def draw_set_weights_text(self, context):
        lines = []
        if bpy.app.version < (5, 0, 0):
            weight = context.scene.tool_settings.unified_paint_settings.weight
        else:
            weight = context.scene.tool_settings.weight_paint.unified_paint_settings.weight
        lines.append([f"[MMB]Weight: {round(weight,3)}", 'p'])
        lines.append([f"[N]ormalize: {self.normalize_select_mode} [L]ock active: {self.lock_active}", 'p'])
        if NORMALIZE_MSG:
            lines.append([NORMALIZE_MSG, 'p'])
        mode = ' '.join([f'[{m[0]}]' if m[0]==self.mix_method else m[0] for m in mix_items])
        lines.append([f"[M]ix method: {mode}", 'p'])
        return lines

    def modal(self, context, event):
        if event.type in ('WHEELUPMOUSE','PAGE_UP') and event.value == 'PRESS':  # page up hack for MAC
            if event.shift:
                self.weight += 0.05
            else:
                self.weight += 0.1
            self.weight = max(min(self.weight,1),0)
            self.run_set_weight(context)

        elif event.type in ('WHEELDOWNMOUSE','PAGE_DOWN') and event.value == 'PRESS':
            if event.shift:
                self.weight -= 0.05
            else:
                self.weight -= 0.1
            self.weight = max(min(self.weight,1),0)
            self.run_set_weight(context)

        elif event.type in {'ESC', }:
            self.disable_handlers()
            # bpy.ops.ed.undo()
            # restore_weights_from_cache(context.active_object)
            self.bm.to_mesh(context.active_object.data)
            self.bm.free()
            context.area.tag_redraw()
            return {'FINISHED'}  # CANCELLED breaks weights restored with restore_weights_from_cache

        elif event.type =='M' and event.value == 'PRESS':
            self.mix_method = self.mix_method_index_cycles.next()
            self.run_set_weight(context)

        elif event.type == "L" and event.value == 'PRESS':
            self.lock_active = not self.lock_active
            self.run_set_weight(context)

        elif event.type =='N' and event.value == 'PRESS':
            print("normalize")
            self.normalize_select_mode = self.normalize_select_mode_loop.next()
            self.run_set_weight(context)

        elif event.type in {'RET', 'LEFTMOUSE', 'RIGHTMOUSE'}:
            self.bm.free()
            self.disable_handlers()
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}

    def weight_set(self,context):
        obj=context.active_object
        VGIndex = obj.vertex_groups.active_index
        activeVertexGroup = obj.vertex_groups[VGIndex]

        sel_verts = [v.index for v in obj.data.vertices if v.select] if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask else [v.index for v in obj.data.vertices]

        if self.weight >= 0:
            activeVertexGroup.add(sel_verts, self.weight, self.mix_method)  # clean old vert
        else:
            activeVertexGroup.remove(sel_verts) # clean old vert

        if self.normalize_select_mode != 'DISABLED':
            # bpy.ops.object.weight_normalize_with_symmetry('INVOKE_DEFAULT',group_select_mode= self.normalize_select_mode, lock_active=self.normalize_lock)
            just_normalize(self.normalize_select_mode, self.lock_active)
            # WPT_OT_CustomNormalize.normalize_with_mirror(obj, self.kd, self.normalize_select_mode, self.normalize_lock)

        # symm = not is_name_r_l(context.active_object.vertex_groups.active.name)
        WPT_OT_MirrorVG.vg_mirror(context, obj, self.kd, target_select='ALL')


    def run_set_weight(self,context, skip_start=False):
        if not skip_start: #undo before setting new value.
            self.save_settings()
            obj = context.active_object
            # if self.mix_method != 'REPLACE': #restore vert weights from bm copy
            self.bm.to_mesh(obj.data)
        if bpy.app.version < (5, 0, 0):
            bpy.context.scene.tool_settings.unified_paint_settings.weight = self.weight
        else:
            bpy.context.scene.tool_settings.weight_paint.unified_paint_settings.weight = self.weight
        self.weight_set(context)
        # bpy.ops.ed.undo_push()


    def invoke(self, context, event):
        if context.object:
            # if self.weight > -1:
            #     if bpy.app.version < (5, 0, 0):
            #         self.weight = bpy.context.scene.tool_settings.unified_paint_settings.weight
            #     else:
            #         self.weight = bpy.context.scene.tool_settings.weight_paint.unified_paint_settings.weight

            obj = context.active_object
            self.kd = build_mesh_kd_tree(obj.data)


            VGIndex = obj.vertex_groups.active_index
            # bpy.ops.ed.undo_push() #to prevetn clearing new ver group on ed.undo() - to slow
            # create_weights_cache(obj, kd)
            self.bm = bmesh.new()   # create an empty BMesh
            self.bm.from_mesh(obj.data)
            if VGIndex == -1:
                # bpy.ops.ed.undo_push() #to prevetn clearing new ver group on ed.undo()
                if has_armature(obj):
                    arm_obj = get_armature_from_active_bone(context, obj)
                    vg_name = arm_obj.data.bones.active.name
                else:
                    vg_name = 'Group'
                vg = obj.vertex_groups.new(name=vg_name)
                obj.vertex_groups.active_index = vg.index
            else:
                vg_name = obj.vertex_groups[VGIndex].name

            is_deform_bone = is_vertex_group_used_for_deformation(obj, vg_name)
            try:
                if is_deform_bone:
                    self.normalize_select_mode = 'BONE_DEFORM' # Dynamic enum..
                else:
                    self.normalize_select_mode = 'DISABLED' # Dynamic enum..
            except:
                self.normalize_select_mode = 'ALL' # Dynamic enum..

            self.normalize_select_mode_loop = EnumListLoop(normalize_items(self,context), default=self.normalize_select_mode) #default ALL

            weight_back = self.weight
            self.load_settings()
            self.weight = weight_back

            self.run_set_weight(context, skip_start=True)
            if self.weight < 0:
                return {'FINISHED'}

            self.draw_text_lines(context, self.draw_set_weights_text, left_margin=20, draw_as='UI')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}



class WPT_OT_SmoothWeights(bpy.types.Operator, GlDrawing):
    bl_idname = "paint.smooth_weights"
    bl_label = "Smooth Weights"
    bl_description = "Smooth weights \n" \
                    "LMB or Enter to accept \n" \
                    "RMB or ESC to cancel"
    bl_options = {"REGISTER", "UNDO"}

    repeat: bpy.props.IntProperty(default=1, name="Repeat", options={'SKIP_SAVE'})
    expand: bpy.props.FloatProperty(name="Expand//Contract", default=0, min=-1, max=1, options={'SKIP_SAVE'})
    normalize_lock: bpy.props.BoolProperty(default=True,name="Normalize Lock", description="Normalize won't affect active vertex group")
    normalize_select_mode : bpy.props.EnumProperty( name="Normalize", items=normalize_items, description="Normalize result (make sum of all weights 1)")
    smooth_target: bpy.props.EnumProperty( name="Group", items = target_items, description="Smooth Target")

    factor = 1

    @classmethod
    def poll(cls, context):
        return context.active_object

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def draw_smooth_weights_data(self, context):
        text_lines = []
        if self.factor == 0.5:
            text_lines.append([f"[MMB] Repeat: {self.repeat * self.factor}", 'p'])
        else:
            text_lines.append([f"[MMB] Repeat: {self.repeat}", 'p'])
        text_lines.append([f"[MMB+shift] Expand: {round(self.expand,2)}", 'p'])
        text_lines.append([f"[N]ormalize: {label_to_clean[self.normalize_select_mode]} [L]ock active: {self.normalize_lock}", 'p'])
        if NORMALIZE_MSG:
            text_lines.append([NORMALIZE_MSG, 'p'])
        text_lines.append([f"Smooth [T]arget: {label_to_clean[self.smooth_target]}", 'p'])
        return text_lines


    def modal(self, context, event):
        if event.type in ('WHEELUPMOUSE','PAGE_UP') and event.value == 'PRESS':  # page up hack for MAC
            if event.shift:
                self.expand +=0.1
            else:
                if self.repeat == 0 and self.factor == 0.5:
                    self.factor = 1
                else:
                    self.repeat += 1
            self.run_smooth(context)

        elif event.type in ('WHEELDOWNMOUSE','PAGE_DOWN') and event.value == 'PRESS':
            if event.shift:
                self.expand -=0.1
            else:
                if self.repeat <= 0:
                    return {'RUNNING_MODAL'}
                if self.repeat == 1 and self.factor == 1:
                    self.factor = 0.5
                else:
                    self.repeat -= 1
            self.run_smooth(context)

        elif event.type == "T" and event.value == 'PRESS':
            self.smooth_target = self.group_select_mode_index_cycles.next()
            self.run_smooth(context)

        elif event.type == "L" and event.value == 'PRESS':
            self.normalize_lock = not self.normalize_lock
            self.run_smooth(context)

        elif event.type =='N' and event.value == 'PRESS':
            self.normalize_select_mode = self.normalize_select_mode_loop.next()
            self.run_smooth(context)

        elif event.type in {'ESC', }:
            self.report({'INFO'}, 'CANCELLED')
            self.disable_handlers()
            # bpy.ops.ed.undo()
            # restore_weights_from_cache(context.active_object)
            self.bm.to_mesh(context.active_object.data)
            self.bm.free()
            context.area.tag_redraw()
            return {'FINISHED'}  # CANCELLED breaks weights restored with restore_weights_from_cache

        elif event.type in {'RET', 'LEFTMOUSE', 'RIGHTMOUSE'}:
            self.disable_handlers()
            self.bm.free()
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}


    def run_smooth(self, context):
        if self.repeat > 0:
            obj = context.active_object
            # restore_weights_from_cache(obj)
            self.bm.to_mesh(obj.data)
            # obj.data.update()
            # back_use_mirror = obj.data.use_mirror_x
            # obj.data.use_mirror_x = False
            try:
                bpy.ops.object.vertex_group_smooth(group_select_mode=self.smooth_target, factor=self.factor, repeat=self.repeat, expand=self.expand)
            except Exception as e:
                print(e)
                self.smooth_target = self.group_select_mode_index_cycles.next()

            if self.normalize_select_mode != 'DISABLED':
                # bpy.ops.object.weight_normalize_with_symmetry('INVOKE_DEFAULT',group_select_mode= self.normalize_select_mode, lock_active=self.normalize_lock)
                just_normalize( self.normalize_select_mode, self.normalize_lock)

            # NOTE: seems vertex_group_smooth  works ok on symmetrical mesh now in blender 3.3 and above (with half selected or not)
            WPT_OT_MirrorVG.vg_mirror(context, obj, self.kd, target_select='ALL')

            # obj.data.use_mirror_x = back_use_mirror


    def invoke(self, context, event):
        obj = context.object
        if obj:
            self.kd = build_mesh_kd_tree(context.active_object.data)

            self.smooth_target = 'ACTIVE' # dynamic enum..
            self.group_select_mode_index_cycles = EnumListLoop(target_items(self,context), default=self.smooth_target)
            active_vg_index = obj.vertex_groups.active_index
            is_deform_bone = True
            if active_vg_index != -1:
                vg_name = obj.vertex_groups[active_vg_index].name
                is_deform_bone = is_vertex_group_used_for_deformation(obj, vg_name)
            try:
                if is_deform_bone:
                    self.normalize_select_mode = 'BONE_DEFORM' # Dynamic enum..
                else:
                    self.normalize_select_mode = 'DISABLED' # Dynamic enum..
            except:
                self.normalize_select_mode = 'ALL' # Dynamic enum..

            self.normalize_select_mode_loop = EnumListLoop(normalize_items(self,context), default=self.normalize_select_mode)

            # create_weights_cache(context.object, kd)
            self.bm = bmesh.new()   # create an empty BMesh
            self.bm.from_mesh(obj.data)

            self.run_smooth(context)
            self.draw_text_lines(context, self.draw_smooth_weights_data, draw_as='UI')

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}


class WPT_OT_LevelsWeights(bpy.types.Operator, GlDrawing):
    bl_idname = "paint.levels_weights"
    bl_label = "Level Weights"
    bl_description = "Level weights\n" \
                    "LMB or Enter to accept \n" \
                    "RMB or ESC to cancel"
    bl_options =  {"REGISTER", "UNDO"}

    offset: bpy.props.FloatProperty(name="Offset", default=0, min=-1, max=1, options={'SKIP_SAVE'})
    gain : bpy.props.FloatProperty(name="Gain", default=1, min=0, max=10, options={'SKIP_SAVE'})
    # normalize: bpy.props.BoolProperty(default=True,name="Normalize", description="Normalize result (make sum of all weights 1)")
    normalize_lock: bpy.props.BoolProperty(default=True,name="Normalize Lock", description="Normalize lock")
    normalize_select_mode  : bpy.props.EnumProperty( name="Normalize", items=normalize_items, description="Normalize result (make sum of all weights 1)")
    levels_target : bpy.props.EnumProperty( name="Target", items = target_items, description="Group Select Mode")

    @classmethod
    def poll(cls, context):
        return context.active_object

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def draw_levels_weights_data(self, context):
        text_lines = []
        text_lines.append([f"[MMB] offset: {round(self.offset,2)}", 'p'])
        text_lines.append([f"[MMB+shift] gain: {round(self.gain,2)}", 'p'])
        text_lines.append([f"[N]ormalize: {label_to_clean[self.normalize_select_mode]} [L]ock active: {self.normalize_lock}", 'p'])
        if NORMALIZE_MSG:
            text_lines.append([NORMALIZE_MSG, 'p'])
        text_lines.append([f"Smooth [T]arget: {label_to_clean[self.levels_target]}", 'p'])
        return text_lines

    def modal(self, context, event):
        if event.type in ('WHEELUPMOUSE','PAGE_UP') and event.value == 'PRESS':  # page up hack for MAC
            if event.shift:
                self.gain +=0.1
            else:
                self.offset +=0.1
            self.run_levels(context)

        elif event.type in ('WHEELDOWNMOUSE','PAGE_DOWN') and event.value == 'PRESS':
            if event.shift:
                self.gain -=0.1
            else:
                self.offset -=0.1
            self.run_levels(context)

        elif event.type == "T" and event.value == 'PRESS':
            self.levels_target = self.levels_target_cycle.next()
            self.run_levels(context)

        elif event.type == "L" and event.value == 'PRESS':
            self.normalize_lock = not self.normalize_lock
            self.run_levels(context)

        elif event.type =='N' and event.value == 'PRESS':
            self.normalize_select_mode = self.normalize_select_mode_loop.next()
            self.run_levels(context)

        elif event.type in {'ESC', }:
            self.report({'INFO'}, 'CANCELLED')
            self.disable_handlers()
            # restore_weights_from_cache(context.active_object)
            self.bm.to_mesh(context.active_object.data)
            self.bm.free()
            context.area.tag_redraw()
            return {'FINISHED'}  # CANCELLED breaks weights restored with restore_weights_from_cache

        elif event.type in {'RET', 'LEFTMOUSE', 'RIGHTMOUSE'}:
            self.disable_handlers()
            self.bm.free()
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}

    def run_levels(self, context):
        obj = context.active_object
        # restore_weights_from_cache(obj)
        self.bm.to_mesh(obj.data)
        # back_use_mirror = obj.data.use_mirror_x
        # obj.data.use_mirror_x = False
        try:
            bpy.ops.object.vertex_group_levels(group_select_mode=self.levels_target,  offset =self.offset , gain=self.gain)
        except Exception as e:
            print(e)
            self.levels_target = self.levels_target_cycle.next()

        if self.normalize_select_mode != 'DISABLED':
            # bpy.ops.object.weight_normalize_with_symmetry('INVOKE_DEFAULT',group_select_mode= self.normalize_select_mode, lock_active=self.normalize_lock)
            just_normalize(self.normalize_select_mode, self.normalize_lock)

        # NOTE: seems vertex_group_smooth  works ok on symmetrical mesh now in blender 3.3 and above (with half selected or not)
        WPT_OT_MirrorVG.vg_mirror(context, obj, self.kd, target_select='ALL')

        # bpy.ops.ed.undo_push()

    def invoke(self, context, event):
        obj = context.object
        if obj:
            # bpy.ops.ed.undo_push()
            self.kd = build_mesh_kd_tree(obj.data)

            self.levels_target = 'ACTIVE' # dynamic enum..
            self.levels_target_cycle = EnumListLoop(target_items(self,context), default=self.levels_target) # default ACTIVE
            active_vg_index = obj.vertex_groups.active_index
            is_deform_bone = True
            if active_vg_index != -1:
                vg_name = obj.vertex_groups[active_vg_index].name
                is_deform_bone = is_vertex_group_used_for_deformation(obj, vg_name)
            try:
                if is_deform_bone:
                    self.normalize_select_mode = 'BONE_DEFORM' # Dynamic enum..
                else:
                    self.normalize_select_mode = 'DISABLED' # Dynamic enum..
            except:
                self.normalize_select_mode = 'ALL' # Dynamic enum..

            self.normalize_select_mode_loop = EnumListLoop(normalize_items(self,context), default=self.normalize_select_mode)


            # create_weights_cache(context.object, kd)
            self.bm = bmesh.new()   # create an empty BMesh
            self.bm.from_mesh(obj.data)
            self.run_levels(context)
            self.draw_text_lines(context, self.draw_levels_weights_data, draw_as='UI')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}


class WPT_OT_SelectActiveVGBone(bpy.types.Operator): #calculate shorter region distance to loop  and selects is.
    bl_idname = "pose.select_active_vg_bone"
    bl_label = "Select active vertex group bone"
    bl_description = "Select active vertex group bone"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        obj = context.active_object
        if not obj.vertex_groups:
            self.report({'ERROR'}, "Active object has no vertex groups. Cancelling")
            return {"CANCELLED"}
        if not obj.vertex_groups.active:
            self.report({'ERROR'}, "No active vertex group. Cancelling")
            return {"CANCELLED"}

        name = obj.vertex_groups.active.name

        for mod in obj.modifiers:
            if mod.type == 'ARMATURE' and mod.object:
                arm_obj = mod.object
                armature_deselect_all_bones(arm_obj)
                if name in arm_obj.data.bones.keys():
                    if arm_obj.mode != 'POSE':
                        arm_obj.hide_set(False)
                        arm_obj.hide_select = False
                        arm_obj.select_set(True)
                        bpy.context.view_layer.objects.active = arm_obj
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.context.view_layer.objects.active = obj
                    # arm_obj.data.bones[name].select = True
                    pbone = arm_obj.pose.bones[name]
                    select_pbone(pbone, True)
                    arm_obj.data.bones.active = arm_obj.data.bones[name]
                    return {"FINISHED"}
        if not has_armature(obj):
            self.report({'INFO'}, "Could not find armature assigned to current object")
        else:
            self.report({'INFO'}, "Bone "+ name + "  not found")
        return {"FINISHED"}



def just_normalize(group_select_mode, lock_active):
    global NORMALIZE_MSG
    if group_select_mode != 'DISABLED':
        try:
            bpy.ops.object.vertex_group_normalize_all(group_select_mode = group_select_mode,
                                                      lock_active = lock_active)
        except RuntimeError as RtErr:
            NORMALIZE_MSG = f"Normalize {RtErr}"
            pass
        else:
            NORMALIZE_MSG = None


class WPT_OT_CustomNormalize(bpy.types.Operator):
    bl_idname = "object.weight_normalize_with_symmetry"
    bl_label = "Normalize All"
    bl_description = "Normalize All vertex weights with symmetry support"
    bl_options = {"REGISTER",'UNDO'}

    group_select_mode: bpy.props.EnumProperty(
        name="Subset",
        items=normalize_items,
        # default='BONE_DEFORM',
        description="Normalize result (make sum of all weights 1)"
    )
    lock_active: bpy.props.BoolProperty(default=True,name="Lock Active", description="Lock Active")
    kd = None

    @classmethod
    def poll(cls, context):
        return True

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def draw(self, context):
        obj = context.active_object
        layout = self.layout
        layout.prop(self, 'group_select_mode')
        layout.prop(self, 'lock_active')


    def execute(self, context):
        obj = context.active_object
        if not self.kd:
            self.kd = build_mesh_kd_tree(obj.data)
        # self.normalize_with_mirror(obj, self.kd, self.group_select_mode, self.lock_active)
        self.normalize_with_mirror_new(context, obj, self.kd, self.group_select_mode, self.lock_active)
        return {"FINISHED"}


    @staticmethod
    def normalize_with_mirror_new(context, obj, kd, group_select_mode, lock_active):
        just_normalize(group_select_mode, lock_active)
        WPT_OT_MirrorVG.vg_mirror(context, obj, kd, group_select_mode)

    @staticmethod
    def normalize_with_mirror(obj, kd, group_select_mode, lock_active):
        global NORMALIZE_MSG
        if group_select_mode != 'DISABLED':
            try:
                bpy.ops.object.vertex_group_normalize_all(group_select_mode = group_select_mode, lock_active = lock_active)
            except RuntimeError as RtErr:
                NORMALIZE_MSG = f"Normalize {RtErr}"
                pass
            else:
                NORMALIZE_MSG = None

        if obj.vertex_groups.active_index == -1:
            if bpy.context.active_pose_bone: #try getting active vg from pbone
                pbone_name = bpy.context.active_pose_bone.name
                if pbone_name not in obj.vertex_groups.keys():
                    return
                obj.vertex_groups.active_index = obj.vertex_groups[pbone_name].index

        if (bpy.context.object.data.use_paint_mask_vertex or bpy.context.object.data.use_paint_mask) and bpy.context.scene.wpt_enable_mirror:
            vg_name = obj.vertex_groups.active.name
            mirrored_vg_name = get_mirrored_name(vg_name)
            mirror_vg_exist = mirrored_vg_name in obj.vertex_groups.keys() if  mirrored_vg_name != '' else False
            #select mirror verts and normalize them, then restore selection
            name_is_rl = is_name_r_l(vg_name)
            if mirror_vg_exist or not name_is_rl:  # group is LT_type or center type
                if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask:
                    sel_verts = [v for v in obj.data.vertices if v.select]
                    #DO mirror select
                    if len(sel_verts) != obj.data.vertices:
                        for v in obj.data.vertices:
                            v.select = False
                        for vert in sel_verts:
                            co, mirror_vert_index, dist = kd.find(Vector((-vert.co[0],vert.co[1],vert.co[2])))
                            if dist < obj.wpt_search_dist:  #delta
                                obj.data.vertices[mirror_vert_index].select = True

                if name_is_rl and mirror_vg_exist:
                    obj.vertex_groups.active_index = obj.vertex_groups[mirrored_vg_name].index
                if group_select_mode != 'DISABLED':
                    try:
                        bpy.ops.object.vertex_group_normalize_all(group_select_mode = group_select_mode, lock_active = lock_active)
                    except RuntimeError as RtErr:
                        NORMALIZE_MSG = f"Normalize {RtErr}"
                        pass
                    else:
                        NORMALIZE_MSG = None

                if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask:  # restore selection
                    for v in obj.data.vertices:
                        v.select = False
                    for v in sel_verts:
                        v.select = True
                obj.vertex_groups.active_index = obj.vertex_groups[vg_name].index

    def invoke(self, context, event):
        obj = context.active_object
        self.kd = build_mesh_kd_tree(obj.data)

        self.group_select_mode = 'ALL'
        return self.execute(context)



class WPT_OT_VGRemoveUnused(bpy.types.Operator):
    bl_idname = "object.vertex_group_remove_unused"
    bl_label = "Remove unused Vertex Groups"
    bl_options = {'REGISTER', 'UNDO'}

    remove_zero_weights: bpy.props.BoolProperty(name="Remove Vertex Groups that have no weights", default=True)
    remove_non_deform_weights: bpy.props.BoolProperty(name="Remove Vertex Groups that are not assigned to any bone", default=False)

    # add draw with properties
    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'remove_zero_weights', expand=True)
        if has_armature(context.active_object):
            layout.prop(self, 'remove_non_deform_weights', expand=True)


    @classmethod
    def poll(cls, context):
        return (context.object is not None and
                context.object.type == 'MESH')

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.object
        obj.update_from_editmode()
        vgroup_used = {i: False for i, k in enumerate(obj.vertex_groups)}
        something_was_removed = False
        if self.remove_zero_weights:
            for v in obj.data.vertices:
                for g in v.groups:
                    if g.weight > 0.0:
                        vgroup_used[g.group] = True

            for i, used in sorted(vgroup_used.items(), reverse=True):
                if not used and not obj.vertex_groups[i].lock_weight:
                    print('Removed group (zero vert weight):' + obj.vertex_groups[i].name)
                    self.report({'INFO'}, 'Removed group (zero vert weight):' + obj.vertex_groups[i].name)
                    obj.vertex_groups.remove(obj.vertex_groups[i])
                    something_was_removed = True

        if self.remove_non_deform_weights and has_armature(obj):
            rem_weights = None
            for mod in obj.modifiers:
                if mod.type == 'ARMATURE':
                    armature_obj = mod.object
                    bone_names = armature_obj.data.bones.keys()
                    weights_to_remove = [vg.name for vg in obj.vertex_groups if vg.name not in bone_names and not vg.lock_weight]
                    if rem_weights:
                        rem_weights = rem_weights.intersection(set(weights_to_remove))
                    else:
                        rem_weights = set(weights_to_remove)

            for vg_name in rem_weights:
                print('Removed group (no bone assigned):' + obj.vertex_groups[vg_name].name)
                self.report({'INFO'}, 'Removed group (no bone assigned):' + obj.vertex_groups[vg_name].name)
                obj.vertex_groups.remove(obj.vertex_groups[vg_name])
                something_was_removed = True
        if not something_was_removed:
            self.report({'INFO'}, 'Nothing found for removal')
        return {'FINISHED'}


class WPT_OT_VGFill(bpy.types.Operator):
    bl_idname = "object.vertex_group_fill"
    bl_label = "Fill vertex weight"
    bl_description = "If vertex weight is low (total sum of vert weights is below 1),"\
        "\nthen increase active vertex group weight until sum reaches 100%"
    bl_options = {'REGISTER', 'UNDO'}


    @classmethod
    def poll(cls, context):
        return (context.object is not None and context.object.type == 'MESH')

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def invoke(self, context, event):
        self.kd = build_mesh_kd_tree(context.active_object.data)
        return self.execute(context)

    def fill_weight(self,context, obj,  group_id):
        if context.object.data.use_paint_mask_vertex:
            verts = [vert for vert in obj.data.vertices if vert.select]
        else:
            verts = [vert for vert in obj.data.vertices]

        vert_total_weight = [0]*len(verts)
        for i,v in enumerate(verts):
            for g in v.groups:
                vert_total_weight[i] += g.weight

        for vert, total_weight in zip(verts, vert_total_weight):
            obj.vertex_groups[group_id].add([vert.index], 1-total_weight, "ADD")

    def execute(self, context):
        obj = context.object
        self.fill_weight(context, obj,  obj.vertex_groups.active_index)
        WPT_OT_MirrorVG.vg_mirror(context, obj, self.kd, target_select='ALL')
        obj.data.update()

        return {'FINISHED'}



@clearable_cache # like 100x faster
def precalc_picked_side(context, obj, sel_verts, auto_pick_side, plus_x):
    ''' Returns: +1 - if we source right side (+X), -1 if we source left side '''
    # if symmetrize in ('FULL','SOFT'):
    if auto_pick_side:
        if context.selected_pose_bones: # try using pose bones position for determining side
            sel_pbones = context.selected_pose_bones
            pbones_x_offset = sum([pbone.matrix.translation[0] for pbone in sel_pbones])

            # maybe sel verts will give better heuristic for detecting selected side for auto_side mirroring
            if len(sel_verts) != len(obj.data.vertices): # not all are selected
                sel_vert_offset = sum([vert.co[0] for vert in sel_verts])
                sel_sign = pbones_x_offset if abs(pbones_x_offset) > abs(sel_vert_offset) else sel_vert_offset
            else:
                sel_sign = pbones_x_offset
        else:  # try using verts for determining side
            sel_sign = sum([vert.co[0] for vert in sel_verts])

        side = 1 if sel_sign >= 0 else -1
    else:  # when sel_verts_side ==  0
        side = -1 if plus_x else 1
    return side


class WPT_OT_MirrorVG(bpy.types.Operator):
    bl_idname = "paint.mirror_vg"
    bl_label = "Mirror Weights"
    bl_description = "Mirror selected vertices weights to opposite side of mesh"
    bl_options = {"REGISTER","UNDO"}

    symmetrize: bpy.props.EnumProperty(
                name="Symmetrize",
                items = (('OFF', "Off", "No symmetrization to vertex groups will be applied"),
                        ('SOFT', "Soft", "Only groups without mirrored pair will be simmetrized e.g. Spine"),
                        ('FULL', "Force", "All groups will be symmetrized! Bone_x.R weights will be assigned to Left and Right side of character!")),
                default='SOFT',
                description="Symmetrize vert groups - both sides can share same weights for some bones - e.g. Spine_x type of bones"
    )
    override_symm_side: bpy.props.BoolProperty(name="Automatically pick sampling side", default=True)
    plus_x: bpy.props.EnumProperty(
                name="Sampling Side",
                items = (('LEFT', "Left", ""),
                        ('RIGHT', "Right", "")),
                default='LEFT',
                description="Sampling Side"
    )

    target_select : bpy.props.EnumProperty(
        name="Target",
        items = target_items,
        description="Group Select Mode"
    )

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def invoke(self, context, event):
        obj = context.active_object
        self.kd = build_mesh_kd_tree(obj.data)
        self.default='ACTIVE'
        bpy.ops.ed.undo_push() # so that operator redo, wont randomly undo previous operation
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'target_select')
        layout.label(text="Symmetrize mode:")
        layout.row().prop(self, 'symmetrize',  expand=True)
        if self.symmetrize in ('SOFT','FULL'):
            layout.prop(self, 'override_symm_side', toggle=True)
            if not self.override_symm_side:
                layout.row().prop(self, 'plus_x', expand=True)


    @staticmethod
    def mirror_execute(context, obj , kd, get_mirrored_vg_idx, symmetrize='OFF', auto_pick_side=True, plus_x=False):
        # copied_v_count = failed_v_count = 0 # DEBUG
        sel_verts = [vert for vert in obj.data.vertices if vert.select] \
            if bpy.context.object.data.use_paint_mask_vertex or bpy.context.object.data.use_paint_mask \
            else [vert for vert in obj.data.vertices]
        if symmetrize in ('SOFT','FULL'):
            sign = precalc_picked_side(context, obj, tuple(sel_verts), auto_pick_side, plus_x)
            sel_verts = [v for v in sel_verts if sign*v.co[0] > obj.wpt_search_dist / 10]  # vert.co < 0

        # old_weights = {v.index:{group.group: group.weight for group in v.groups if get_mirrored_vg_idx.get(group.group)!=None} for v in sel_verts}
        # current_weights = {v.index:{group_id: 0 for group_id in  get_mirrored_vg_idx.keys()} for v in sel_verts} # set all vert[idx] -> group.x -> weights to 0
        # for v in sel_verts: # then fill them with non 0 weights, if ver
        #     for group in v.groups:
        #         if get_mirrored_vg_idx.get(group.group)!=None: # has target for mirrored vg.r ?
        #             current_weights[v.index][group.group] = group.weight

        new_weights = {} # NOTE: mirror_cache[mirrored_vert.index][vgroup.id] = other_side_weight (first calc target_weight, then in next step write)
        for vert in sel_verts:
            _, mirror_vert_id, dist = kd.find(Vector((-vert.co[0], vert.co[1], vert.co[2])))
            if dist < obj.wpt_search_dist:
                new_weights[mirror_vert_id] = {}
                # copied_v_count += 1
                # avg_weight_all = {group.group: group.weight for group in vert.groups}
                for g_data in vert.groups:
                    target_id = get_mirrored_vg_idx.get(g_data.group) # should contain g_id... for FULL symmetrize
                    if target_id != None: # None for locked weights..
                        new_weights[mirror_vert_id][target_id] = g_data.weight

                # for g_id, weight in current_weights[vert.index].items():
                #     target_id = get_mirrored_vg_idx[g_id] # should contain g_id... for FULL symmetrize
                #
                #     if target_id != None: # None for locked weights..
                #         new_weights[mirror_vert_id][target_id] = weight
            # else: #no source wert found so skip it
            #     failed_v_count += 1

        # zero_weight_verts = {index for (index, weight) in mirror_cache.items() if weight == 0}
        # join get_mirrored_vg_idx keys and values int one 'affected_groups' set
        affected_groups = set(get_mirrored_vg_idx.keys()) | set(get_mirrored_vg_idx.values())
        for vert_id, vert_new_weights in new_weights.items():
            # remove old vert groups if they are in get_mirrored_vg_idx.keys() - meaning they are vg targets to mirror
            # clean_vgroups_ids = [group.group for group in obj.data.vertices[vert_id].groups if get_mirrored_vg_idx.get(group.group) != None]
            clean_old_vgroups_ids = [group.group for group in obj.data.vertices[vert_id].groups if group.group in affected_groups]
            for old_g in clean_old_vgroups_ids:
                obj.vertex_groups[old_g].remove([vert_id])
            for g, weight in vert_new_weights.items():
                # if weight < 0.001:
                #     obj.vertex_groups[g].remove([vert_id])
                # else:
                obj.vertex_groups[g].add([vert_id], weight, "REPLACE")
        # mesh.update()
        # print("Weights symmetrized on: " + str(copied_v_count) + " out of " + str(copied_v_count + failed_v_count) + " vertices")


    @staticmethod
    def vg_mirror(context, obj, kd, target_select='ACTIVE', symmetrize='SOFT', override_symm_side=True, plus_x=False):
        """ Mirror weights from one side to another, but also Symmetrize 'FULL' and 'SOFT'

        Args:
            context ():
            obj ():
            kd ():
            target_select ():
            symmetrize ():  'OFF',
                            'SOFT' - symmetrize only when no matching is_name_r_l (eg SpineX),  - has to pick axis ..automagically
                            'FULL' - always symmetrize (only used in mirror operator) - has to pick axis auto or manual (from mirror operator)
            override_symm_side ():
            plus_x ():

        Returns:

        """
        if not (context.scene.wpt_enable_mirror and obj.use_mesh_mirror_x):
            return
        active_vg_idx = obj.vertex_groups.active_index

        get_mirrored_vg_idx = build_ids_to_mirrored_ids(context, obj, target_select, symmetrize) # may change active vgroup..

        obj.vertex_groups.active_index = active_vg_idx #restore active
        if get_mirrored_vg_idx:
            WPT_OT_MirrorVG.mirror_execute(context, obj, kd, get_mirrored_vg_idx, symmetrize=symmetrize, auto_pick_side=override_symm_side, plus_x=plus_x)
        else:
            print("Nothing to mirror")


    def execute(self, context):
        obj = context.active_object
        if not obj.use_mesh_mirror_x:
            self.report({'WARNING'}, f'{obj.name} has no X mesh symmetry enabled. Turning it on')
            obj.use_mesh_mirror_x = True
        if not context.scene.wpt_enable_mirror:
            self.report({'WARNING'}, 'Mirror is disabled in WPT settings. Enabling: Ctrl+X > Mirroring')
            context.scene.wpt_enable_mirror = True
        sampling_side = 1 if self.plus_x == 'RIGHT' else 0
        self.vg_mirror(context, obj, self.kd, self.target_select, self.symmetrize, self.override_symm_side, sampling_side)

        # select the mirror bone
        active_vg_name = obj.vertex_groups.active.name
        mirrored_vg_name = get_mirrored_name(active_vg_name)
        if mirrored_vg_name and self.target_select == 'ACTIVE' and self.symmetrize == 'OFF':
            if has_armature(obj):
                armature_obj = get_armature_from_active_bone(bpy.context, obj)
                if armature_obj:
                    armature_deselect_all_bones(armature_obj)
                    if mirrored_vg_name in armature_obj.data.bones:
                        armature_obj.data.bones[mirrored_vg_name].select = True
                        armature_obj.data.bones.active = armature_obj.data.bones[mirrored_vg_name]
                target_vg_index = obj.vertex_groups[mirrored_vg_name].index
                obj.vertex_groups.active_index = target_vg_index
        return {"FINISHED"}



class WPT_OT_MirrorVG_Project(bpy.types.Operator):
    bl_idname = "paint.mirror_vg_project"
    bl_label = "Mirror Project Weights"
    bl_description = "Receive weights on selected verts, from opposite side of mesh. \nWorks ok with non symmetrical topology meshes"
    bl_options = {"REGISTER","UNDO"}

    symmetrize: bpy.props.EnumProperty(
                name="Symmetrize",
                items = (('OFF', "Off", "No symmetrization to vertex groups will be applied"),
                        ('SOFT', "Soft", "Only groups without mirrored pair will be simmetrized e.g. Spine"),
                        ('FULL', "Force", "All groups will be symmetrized! Bone_x.R weights will be assigned to Left and Right side of character!")),
                default='SOFT',
                description="Symmetrize vert groups - both sides can share same weights for some bones - e.g. Spine_x type of bones"
    )
    override_symm_side: bpy.props.BoolProperty(name="Automatically pick sampling side", default=True)
    plus_x: bpy.props.EnumProperty(
                name="Sampling Side",
                items = (('LEFT', "Left", ""),
                        ('RIGHT', "Right", "")),
                default='LEFT',
                description="Sampling Side"
    )

    target_select : bpy.props.EnumProperty(
        name="Target",
        items = target_items,
        description="Group Select Mode"
    )

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def invoke(self, context, event):
        self.target_select = 'ALL' # dynamice enum!
        obj = context.active_object
        if not obj.use_mesh_mirror_x:
            self.report({'WARNING'}, f'{obj.name} has no X mesh symmetry enabled. Turning it on')
            obj.use_mesh_mirror_x = True
        if not context.scene.wpt_enable_mirror:
            self.report({'WARNING'}, 'Mirror is disabled in WPT settings. Enabling: Ctrl+X > Mirroring')
            context.scene.wpt_enable_mirror = True
        bpy.ops.ed.undo_push() # avoid undoing previews operation ran before mirror project...
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'target_select')
        layout.label(text="Symmetrize mode:")
        layout.row().prop(self, 'symmetrize',  expand=True)
        if self.symmetrize in ('SOFT','FULL'):
            layout.prop(self, 'override_symm_side', toggle=True)
            if not self.override_symm_side:
                layout.row().prop(self, 'plus_x', expand=True)

    @staticmethod
    def mirror_proj_execute(context, obj, get_mirrored_vg_idx, symmetrize='OFF', auto_pick_side=True, plus_x=False):
        obj=context.active_object
        mesh = obj.data

        bm = bmesh.new()   # create an empty BMesh
        bm.from_mesh(mesh)   # fill it in from a Mesh
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        w_lay = bm.verts.layers.deform.active  # vertex groups
        # INFO: vert[w_lay] is dict - group.ids: g.weights

        bvht_tree = BVHTree.FromBMesh(bm)

        sel_verts = [vert for vert in bm.verts if vert.select] \
            if bpy.context.object.data.use_paint_mask_vertex or bpy.context.object.data.use_paint_mask \
            else [vert for vert in bm.verts]
        if symmetrize in ('SOFT','FULL'):
            sign = precalc_picked_side(context, obj, tuple(sel_verts), auto_pick_side, plus_x)
            sel_verts = [v for v in sel_verts if sign*v.co[0] > obj.wpt_search_dist / 10]  # vert.co < 0

        new_weights = {} # NOTE: mirror_cache[mirrored_vert.index][vgroup.id] = other_side_weight (first calc target_weight, then in next step write)
        search_dist = 22 # whatever?
        for vert in sel_verts:
            co, norm, face_index, dist = bvht_tree.find_nearest(Vector((-vert.co[0], vert.co[1], vert.co[2])), search_dist)

            if dist < obj.wpt_search_dist:
                avg_weight_all = get_baryc_vgroups_weights(bm.faces[face_index],w_lay, co, get_mirrored_vg_idx)
                new_weights[vert.index] = {}
                # copied_v_count += 1
                for g_id, weight in avg_weight_all.items():
                    target_id = get_mirrored_vg_idx[g_id] # should contain g_id... for FULL symmetrize
                    if target_id != None: # None for locked weights..
                        new_weights[vert.index][target_id] = weight

        affected_groups = set(get_mirrored_vg_idx.keys()) | set(get_mirrored_vg_idx.values())
        # print(f"{affected_groups=}")
        # zero_weight_verts = {index for (index, weight) in mirror_cache.items() if weight == 0}
        for vert_id, vert_new_weights in new_weights.items():
            # DONE: in future we should not clear: locked vg, or non deformer vg (if Deformer Vgroups are selected...)
            # NOPE (won't work): maybe handle it from get_avg_weight_all - if all weights is sel, then: vert[all_empty_vg] = 0, rathter than None, then write these 0s
            if len(get_mirrored_vg_idx)>2: # HACK: assume we are moving all groups... - clear old ones if not in received vg_list
                clean_old_vgroups_ids = [group_id for group_id in bm.verts[vert_id][w_lay].keys() if group_id in affected_groups]
                for old_g in clean_old_vgroups_ids:
                    if bm.verts[vert_id][w_lay].get(old_g): del bm.verts[vert_id][w_lay][old_g]

            for g, weight in vert_new_weights.items():
                # if weight < 0.001:
                #     obj.vertex_groups[g].remove([vert_id])
                # else:
                bm.verts[vert_id][w_lay][g] = weight
                # obj.vertex_groups[g].add([vert_id], weight, "REPLACE")
        bm.to_mesh(mesh)
        bm.free()  # free and prevent further access
        obj.data.update()
        # print("Weights symmetrized on: " + str(copied_v_count) + " out of " + str(copied_v_count + failed_v_count) + " vertices")


    def vg_mirror_project(self,context, obj, target_select='ACTIVE', symmetrize='SOFT', override_symm_side=True, plus_x=False):
        """ Mirror weights from one side to another, but also Symmetrize 'FULL' and 'SOFT'

        Args:
            context ():
            obj ():
            kd ():
            target_select ():
            symmetrize ():  'OFF',
                            'SOFT' - symmetrize only when no matching is_name_r_l (eg SpineX),  - has to pick axis ..automagically
                            'FULL' - always symmetrize (only used in mirror operator) - has to pick axis auto or manual (from mirror operator)
            override_symm_side ():
            plus_x ():

        Returns:

        """
        if not (context.scene.wpt_enable_mirror and obj.use_mesh_mirror_x):
            return
        active_vg_idx = obj.vertex_groups.active_index

        get_mirrored_vg_idx = build_ids_to_mirror_projected_ids(context, obj, target_select, symmetrize) # as vg.ids

        obj.vertex_groups.active_index = active_vg_idx #restore active
        if get_mirrored_vg_idx:
            self.mirror_proj_execute(context, obj, get_mirrored_vg_idx,
                            symmetrize=symmetrize, auto_pick_side=override_symm_side, plus_x=plus_x)
        else:
            print("Nothing to mirror")


    def execute(self, context):
        obj = context.active_object
        sampling_side = 1 if self.plus_x == 'RIGHT' else 0
        self.vg_mirror_project(context, obj, self.target_select, self.symmetrize, self.override_symm_side, sampling_side)

        # select the mirror bone
        active_vg_name = obj.vertex_groups.active.name
        mirrored_vg_name = get_mirrored_name(active_vg_name)
        if mirrored_vg_name and self.target_select == 'ACTIVE' and self.symmetrize == 'OFF':
            if has_armature(obj):
                armature_obj = get_armature_from_active_bone(bpy.context, obj)
                if armature_obj:
                    armature_deselect_all_bones(armature_obj)
                    if mirrored_vg_name in armature_obj.data.bones:
                        armature_obj.data.bones[mirrored_vg_name].select = True
                        armature_obj.data.bones.active = armature_obj.data.bones[mirrored_vg_name]
                target_vg_index = obj.vertex_groups[mirrored_vg_name].index
                obj.vertex_groups.active_index = target_vg_index
        return {"FINISHED"}




class WPT_OT_PickWeight(bpy.types.Operator):
    bl_idname = "paint.pick_weight"
    bl_label = "Pick Weight"
    bl_description = "Pick Weight - get weight from active vertex group"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        obj = context.active_object
        active_vg_id=obj.vertex_groups.active_index
        for vert in obj.data.vertices:
            if vert.select:
                for group in vert.groups:
                    if group.group == active_vg_id:
                        if bpy.app.version < (5, 0, 0):
                            context.scene.tool_settings.unified_paint_settings.weight=group.weight
                        else:
                            context.scene.tool_settings.weight_paint.unified_paint_settings.weight=group.weight
                        return {"FINISHED"}

        return {"FINISHED"}



class WPT_OT_ProjectWeights(bpy.types.Operator):
    bl_idname = "object.project_weights"
    bl_label = "Project weights"
    bl_description = "Project weights from non selected mesh parts to selection"
    bl_options = {"REGISTER","UNDO"}

    all_groups: bpy.props.BoolProperty(name="All Groups", default=True)

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        receiver = context.active_object
        active_vg = receiver.vertex_groups.active
        source_id = receiver.vertex_groups.active.index
        sel_verts_ids = [v.index for v in receiver.data.vertices if v.select]
        if not sel_verts_ids:
            self.report({'ERROR'}, 'Select some vertices First')
            return {'CANCELLED'}
        if len(sel_verts_ids) == len(receiver.data.vertices):
            self.report({'ERROR'}, 'Select only part of object (that will receive weights from non selected geometry)')
            return {'CANCELLED'}

        mesh = receiver.data

        bm_receiver = bmesh.new()   # create an empty BMesh
        bm_receiver.from_mesh(mesh)   # fill it in from a Mesh
        bm_receiver.verts.ensure_lookup_table()

        bm_source = bmesh.new()   # create an empty BMesh
        bm_source.from_mesh(mesh)   # fill it in from a Mesh
        sel_verts = [v for v in bm_source.verts if v.select]
        bmesh.ops.delete(bm_source, geom = sel_verts, context = 'VERTS')
        bm_source.verts.ensure_lookup_table()
        bm_source.faces.ensure_lookup_table()

        w_lay_rec = bm_receiver.verts.layers.deform.active  # vertex groups
        w_lay_src = bm_source.verts.layers.deform.active  # vertex groups
        #* vert[w_lay] is dict - group.ids: g.weights

        bvht_tree = BVHTree.FromBMesh(bm_source)
        sel_verts = [v for v in bm_receiver.verts if v.select]
        for vert in sel_verts:
            search_dist = 11
            co, norm, face_index, dist = bvht_tree.find_nearest(Vector((vert.co[0], vert.co[1], vert.co[2])), search_dist)
            if face_index is not None:
                if self.all_groups:
                    vert[w_lay_rec].clear()
                    avg_weight_all = get_baryc_vgroups_weights(bm_source.faces[face_index], w_lay_src, co)
                    for g_id, weight in avg_weight_all.items():
                        vert[w_lay_rec][g_id] = weight
                else:
                    avg_weight = get_avg_weight(bm_source.faces[face_index], w_lay_src, co, source_id)
                    vert[w_lay_rec][source_id] = avg_weight
            else:
                print(f'not hit for vert{vert.index}')

        bm_receiver.to_mesh(mesh)
        bm_source.free()  # free and prevent further access
        bm_receiver.free()  # free and prevent further access
        receiver.data.update()
        return {"FINISHED"}

class WPT_OT_CopyWeight(bpy.types.Operator):
    bl_idname = "object.copy_vg_weight"
    bl_label = "Copy Vertex weights"
    bl_description = "Copy all Vertex weights from selection. Selection order matters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj=context.active_object
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        sel_vert_ids = bmesh_sel_verts_history(bm)

        if not sel_vert_ids:
            bm.verts.ensure_lookup_table()
            sel_vert_ids = [v.index for v in bm.verts if v.select]
            if len(sel_vert_ids) > 1:
                bm.free()
                self.report({'ERROR'}, 'Selection history does not exist! Reselect vertics and try again')
                return {'CANCELLED'}

        if sel_vert_ids:
            sel_verts2 = [obj.data.vertices[sel_vert_id] for sel_vert_id in sel_vert_ids]
            groups = []
            weights = []
            for i,sel_vert in enumerate(sel_verts2):
                groups.append([obj.vertex_groups[group.group].name for group in sel_vert.groups])
                weights.append([group.weight for group in sel_vert.groups])
            bpy.context.window_manager['verts_weight_copies']= {'groups':groups,'weights':weights}
        else:
            self.report({'ERROR'}, 'Nothting is selected! Select at least one vert to copy weights form!')
        bm.free()
        return {"FINISHED"}


class WPT_OT_InterpolateOverride(bpy.types.Operator):
    bl_idname = "object.interpolate_override"
    bl_label = "Override from adjacent"
    bl_description = "Override selected verts weights from adjacent vertices. Helpfull in removing broken vertices."
    bl_options = {"REGISTER","UNDO"}

    normalize: bpy.props.BoolProperty(name='Normalize result', default=False)
    affected_group: bpy.props.EnumProperty(name='Affected group', description='Affected group',
        items=[ ('ALL', 'All', ''), ('ACTIVE', 'Active', '') ], default='ALL')

    @classmethod
    def poll(cls, context):
        return context.active_object and (bpy.context.object.data.use_paint_mask_vertex or bpy.context.object.data.use_paint_mask)

    def execute(self, context):
        obj = context.active_object
        me = obj.data
        # cache_verts_weights = {vert.index: {group.group: group.weight for group in vert.groups if group.weight} for vert in sel_verts}

        bm = bmesh.new()   # create an empty BMesh
        bm.from_mesh(me)   # fill it in from a Mesh
        bm.verts.ensure_lookup_table()

        sel_verts = [v for v in bm.verts if v.select]
        w_lay = bm.verts.layers.deform.active #vertex groups
        #* vert[w_lay] is dict - group.ids: g.weights
        max_iters = 11
        i = 0
        active_vg_id = obj.vertex_groups.active_index

        used_groups = [active_vg_id] if self.affected_group == 'ACTIVE' else list({g_id for vert in sel_verts for g_id in vert[w_lay].keys()})
        while len(sel_verts):
            done_verts = []
            for v in sel_verts:
                verts_was_averaged = False
                v_weights_tmp = {g_id: 0 for g_id in used_groups} #cant write to v[w_lay] weights bigger than 1, so use temp dict
                current_vert_group_count = {g_id: 0 for g_id in used_groups} #coutn how many times group x was added from neibors
                for e in v.link_edges: # from neibors verts
                    linked_vert = e.other_vert(v)
                    if linked_vert not in sel_verts: #in first pass ini verts from outside selection
                        verts_was_averaged = True
                        if self.affected_group == 'ACTIVE':
                            v_weights_tmp[active_vg_id] += linked_vert[w_lay][active_vg_id] if active_vg_id in linked_vert[w_lay].keys() else 0
                            current_vert_group_count[active_vg_id] += 1
                        else:
                            for g_id in used_groups:  # copy weigts form linked_vert
                                v_weights_tmp[g_id] += linked_vert[w_lay][g_id] if g_id in linked_vert[w_lay].keys() else 0
                                current_vert_group_count[g_id] +=1
                if verts_was_averaged:  # if not empty weights, then vert was initialized. Mark it as done
                    done_verts.append(v)
                    for g_id in v_weights_tmp.keys():
                        if current_vert_group_count[g_id]: #to avoid div by 0
                            v[w_lay][g_id] = v_weights_tmp[g_id] / current_vert_group_count[g_id]
            sel_verts = list(set(sel_verts) - set(done_verts))#remove interpolated verts from sel_verts list
            done_verts = []
            i+=1
            if i > max_iters:
                bm.to_mesh(me)
                bm.free()  # free and prevent further access
                self.report({'ERROR'}, 'Could not interpolate all vertices. Maximum iteration count exceeded. Finishing')
                return {'FINISHED'}


        bm.to_mesh(me)
        bm.free()  # free and prevent further access
        obj.data.update()
        bpy.ops.object.vertex_group_smooth(group_select_mode='ALL', factor=0.5, repeat=1, expand=0)
        #? normalize
        if self.normalize:
            lock = True if self.affected_group == 'ACTIVE' else False
            bpy.ops.object.vertex_group_normalize_all(lock_active=lock)


        return {"FINISHED"}


class WPT_OT_PasteVWeight(bpy.types.Operator):
    bl_idname = "object.paste_vg_weight"
    bl_label = "Paste Vertex weights"
    bl_description = "Paste all Vertex weights to selection. Selection order matters"
    bl_options = {'REGISTER', 'UNDO'}

    # def __init__(self):
    #     clear_all_cached_functions()

    def __init__(self, *args, **kwargs): # Since blender 4.4
        super().__init__(*args, **kwargs)
        clear_all_cached_functions()

    def invoke(self, context, event):
        self.kd = build_mesh_kd_tree(context.active_object.data)
        return self.execute(context)

    def execute(self, context):
        obj=context.active_object
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        sel_vert_ids = bmesh_sel_verts_history(bm)
        bm.free()
        if sel_vert_ids:
            sel_verts_history = [obj.data.vertices[sel_vert_id] for sel_vert_id in sel_vert_ids]
        else:
            sel_verts_history = []
        sel_verts = [vert for vert in obj.data.vertices if vert.select]
        if len(sel_verts_history)==len(sel_verts): #use history if same amount of verts, else use selection
            sel_verts = sel_verts_history
        vg_cache = bpy.context.window_manager['verts_weight_copies']
        unique_groups = {group_name for g_list in vg_cache['groups'] for group_name in g_list}
        for group_name in unique_groups:
            if group_name not in obj.vertex_groups.keys():
                obj.vertex_groups.new(name=group_name)
        for sel_vert, verts_groups_names, verts_weights in zip(sel_verts, cycle(vg_cache['groups']), cycle(vg_cache['weights'])):
            for group in reversed(sel_vert.groups):
                obj.vertex_groups[group.group].remove([sel_vert.index])
            for group_name, weight in zip(verts_groups_names, verts_weights):
                obj.vertex_groups[group_name].add([sel_vert.index], weight, "REPLACE")
        obj.data.update()
        WPT_OT_MirrorVG.vg_mirror(context, obj, self.kd, target_select='ALL')

        self.report({'INFO'}, "Weights pasted")
        return {"FINISHED"}


def items_callback(scene, context):
    return [(vg.name,vg.name,'') for vg in context.active_object.vertex_groups]


class WPT_OT_MixVertexGroups(bpy.types.Operator):
    bl_idname = "object.transfer_weights"
    bl_label = "Transfer Vertex Weights"
    bl_description = "Transfer Vertex Weights. \n"\
                "Select source bone A - then target bone - B. Weights on selected verts will be moved from A to B"
    bl_options = {"REGISTER", "UNDO"}

    mix_method: bpy.props.EnumProperty(
        name="Mix method",
        items = (('REPLACE', "Replace", ""),
                ('ADD', "Add", ""),
                ('LIGHTEN', "Lighten", ""),
                ('DIFFERENCE', "Difference", ""),
                ('MULTIPLY', "Multiply", "")),
        default='ADD',
        description="Mix method"
    )

    clear_source: bpy.props.BoolProperty(name="Clear Source Weights", default=True)
    source_vg_name: bpy.props.EnumProperty( name="Sourve Vertex Group", items=items_callback, description="Source Vertex Group")

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object

        src_vg = obj.vertex_groups[self.source_vg_name]
        mirr_source_vg_name = get_mirrored_name(self.source_vg_name)
        mirr_src_vg = obj.vertex_groups.get(mirr_source_vg_name, None)

        target_vg = obj.vertex_groups[self.target_vg_name]
        mirr_target_vg_name = get_mirrored_name(self.target_vg_name)
        mirr_target_vg = obj.vertex_groups.get(mirr_target_vg_name, None)

        # mirr Target is empty (center bone?), try transferring from mirrored source group
        if mirr_target_vg_name == '' and mirr_src_vg:
            if self.mix_method in {'REPLACE', 'DIFFERENCE', 'MULTIPLY'}:
                bpy.ops.object.vertex_group_add()  #create temp group for storing sum of left + right source groups
                obj.vertex_groups.active.name = 'temp_for_mix'
                if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask:
                    verts = [v for v in obj.data.vertices if v.select]
                else:
                    verts = [v for v in obj.data.vertices]
                src_groups_indices = {src_vg.index, mirr_src_vg.index}
                for vert in verts:
                    for group in vert.groups:
                        if group.group in src_groups_indices:
                            obj.vertex_groups.active.add([vert.index], group.weight, "ADD") # (vertIndex,weight,replace)
                self.mix_weights(obj, target_vg, 'temp_for_mix')
                bpy.ops.object.vertex_group_remove(all=False, all_unlocked=False) #remove temp
                obj.vertex_groups.active_index = target_vg.index

                if self.clear_source:
                    for vert in verts:
                        src_vg.add([vert.index], 0, 'REPLACE')
                        mirr_src_vg.add([vert.index], 0, 'REPLACE')
                return {"FINISHED"}

        self.mix_weights(obj, target_vg, src_vg)

        # if src has mirrored counterpart, then transfer it too
        if mirr_src_vg  and mirr_src_vg != target_vg:
            # transfer to either target or mirrored target
            sub_target = self.target_vg_name if mirr_target_vg_name =='' else mirr_target_vg_name #cos we may want to merge 2ver groups to middle (non symetrical) group
            if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask:
                sel_verts = [v for v in obj.data.vertices if v.select]
                #DO mirror select
                if len(sel_verts) != obj.data.vertices:
                    for v in obj.data.vertices:
                        v.select = False

                    copied_v_count = failed_v_count = 0
                    for vert in sel_verts:
                        co, mirror_vert_index, dist = self.kd.find(Vector((-vert.co[0],vert.co[1],vert.co[2])))
                        if dist< obj.wpt_search_dist:  #delta
                            obj.data.vertices[mirror_vert_index].select = True
                            copied_v_count +=1
                        else:
                            failed_v_count +=1

            sub_target = obj.vertex_groups.get(sub_target, None)
            self.mix_weights(obj, sub_target, mirr_src_vg)
            if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask:
                for v in obj.data.vertices:
                    v.select = False
                for v in sel_verts:
                    v.select = True

        return {"FINISHED"}

    def mix_weights(self, obj, target_vg, src_vg):
        if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask:
            verts = [v for v in obj.data.vertices if v.select]
        else:
            verts = [v for v in obj.data.vertices]

        for vert in verts:
            id = vert.index
            source_weight = target_weight = 0
            vert_group_index = [v_group.group for v_group in vert.groups]
            if target_vg.index in vert_group_index:
                source_weight = target_vg.weight(id)
            if src_vg.index in vert_group_index:
                target_weight = src_vg.weight(id)

            # only add to vertex group is weight is > 0
            if self.mix_method == 'ADD':
                out_weight = source_weight + target_weight
            elif self.mix_method == 'REPLACE':
                out_weight = target_weight
            elif self.mix_method == 'DIFFERENCE':
                out_weight =  max(source_weight - target_weight,0)
            elif self.mix_method == 'LIGHTEN':
                out_weight = max(source_weight, target_weight)
            elif self.mix_method == 'MULTIPLY':
                out_weight = source_weight * target_weight
            # if out_weight>0:
            target_vg.add([id], out_weight, 'REPLACE')
            if self.clear_source:
                src_vg.add([id], 0, 'REPLACE')
        obj.data.update()
        self.report({'INFO'}, "Weights transferred from bone: "+ src_vg.name + "  to: "+target_vg.name)


    def invoke(self, context, event):
        obj = context.active_object
        if not obj.vertex_groups.active:
            bpy.ops.paint.weight_set_wp('INVOKE_DEFAULT',weight=0)
        active_vg_name = obj.vertex_groups.active.name

        armature_obj = get_armature_from_active_bone(context, obj)
        # armature_obj.data.bones[active_vg_name].select = True
        if bpy.app.version <  (5, 0, 0):
            selected_pbones_name = [bone.name for bone in armature_obj.data.bones if bone.select]
        else:
            selected_pbones_name = [pbone.name for pbone in armature_obj.pose.bones if pbone.select]

        if len(selected_pbones_name)!=2:
            self.report({'ERROR'}, 'Select two bones for weight transfer! Cancelling')
            return {'CANCELLED'}

        armature_obj.data.bones.active = armature_obj.data.bones[active_vg_name]
        self.target_vg_name = obj.vertex_groups.active.name

        if selected_pbones_name[0] != self.target_vg_name:
            self.source_vg_name = selected_pbones_name[0]
        else:
            self.source_vg_name = selected_pbones_name[1]


        if obj.data.use_paint_mask_vertex or obj.data.use_paint_mask:
            self.kd = build_mesh_kd_tree(obj.data)

        return self.execute(context)


class WPT_OT_SelectBoneVP(bpy.types.Operator):
    bl_idname = "paint.select_bone_wp"
    bl_label = "Select bone WP"
    bl_options = {"REGISTER", "UNDO"}

    extendSel:  bpy.props.BoolProperty(default=False)

    def execute(self, context):
        # bpy.ops.view3d.select(extend=False, deselect=False, toggle=False, center=False, enumerate=False, object=False, location=(652, 205))
        obj = context.active_object
        use_paint_mask_vertex = obj.data.use_paint_mask_vertex
        use_paint_mask = obj.data.use_paint_mask
        use_paint_bone_selection = obj.data.use_paint_bone_selection
        obj.data.use_paint_bone_selection = True
        bpy.ops.view3d.select('INVOKE_DEFAULT', extend = self.extendSel)
        obj.data.use_paint_bone_selection = use_paint_bone_selection
        obj.data.use_paint_mask_vertex = use_paint_mask_vertex
        obj.data.use_paint_mask = use_paint_mask
        return {'FINISHED'}


class WPT_OT_SelectLoop(bpy.types.Operator):
    bl_idname = "paint.loop_select_wp"
    bl_label = "Loop Select WP"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        for mod in context.active_object.modifiers:
            if mod.type == 'ARMATURE':
                mod.show_in_editmode = True
                mod.show_on_cage =True
        bpy.ops.mesh.loop_select('INVOKE_DEFAULT')
        bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
        return {'FINISHED'}


class WPT_OT_SelectExtendLoop(bpy.types.Operator):
    bl_idname = "paint.loop_select_extend_wp"
    bl_label = "Loop Select WP"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        if has_armature(context.active_object):
            arma_mod = get_first_armature_mod(context.active_object)
            arma_mod.show_in_editmode = True
            arma_mod.show_on_cage =True
        bpy.ops.mesh.loop_select('INVOKE_DEFAULT', toggle=True)
        bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
        return {'FINISHED'}


class WPT_OT_GrowSelect(bpy.types.Operator):
    bl_idname = "paint.grow_select_wp"
    bl_label = "Grow Select WP"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        bpy.ops.mesh.select_more('INVOKE_DEFAULT')
        bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
        return {'FINISHED'}


class WPT_OT_ShrinkSelect(bpy.types.Operator):
    bl_idname = "paint.shrink_select_wp"
    bl_label = "Shrink Select WP"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        bpy.ops.mesh.select_less('INVOKE_DEFAULT')
        bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
        return {'FINISHED'}


class WPT_OT_SelectLinked(bpy.types.Operator):
    bl_idname = "paint.select_linked_wp"
    bl_label = "Select Linked WP"
    bl_options = {"REGISTER", "UNDO"}

    limit: bpy.props.EnumProperty(
        name="Limit",
        options={'ENUM_FLAG'},
        items = (('NORMAL', "NORMAL", ""),
                            ('SEAM', "SEAM", ""),
                            ('UV', "UV", ""),
                            ('SHARP', "SHARP", "")),
        # default={'SHARP'},
        description="Limit Method"
    )

    def execute(self, context):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        bpy.ops.mesh.select_linked('INVOKE_DEFAULT' ,delimit=self.limit)
        bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
        return {'FINISHED'}


class WPT_OT_HideSelected(bpy.types.Operator):
    bl_idname = "paint.hide_selected_wp"
    bl_label = "Hide Selected WP"
    bl_options = {"REGISTER", "UNDO"}

    hide_mode: bpy.props.EnumProperty(name='Hide Mode', description='',
        items=[
            ('HIDE', 'Hide', 'Description...'),
            ('REVEAL', 'Reveal', 'Description...'),
            ('ISOLATE', 'Isolate', 'Description...')
        ], default='HIDE')

    def execute(self, context):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        if self.hide_mode == 'HIDE':
            bpy.ops.mesh.hide(unselected=False)
        elif self.hide_mode == 'REVEAL':
            bpy.ops.mesh.reveal()
        elif self.hide_mode == 'ISOLATE':
            bpy.ops.mesh.hide(unselected=True)
        bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
        return {'FINISHED'}

