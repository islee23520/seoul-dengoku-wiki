'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO
Thanks to Jaroslaw Cwik for Ideas on aligning curves tilt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import bpy
from mathutils.interpolate import poly_3d_calc
import bmesh
import math
from mathutils import Vector, kdtree
from math import log10, floor
import re
from functools import cache

cached_functions = []

def clearable_cache(func):
    cfun = cache(func)
    cached_functions.append(cfun)
    return cfun

def clear_all_cached_functions():
    for func in cached_functions:
        func.cache_clear()


def bmesh_vert_active(bm):
    if bm.select_history:
        elem = bm.select_history[-1]
        if isinstance(elem, bmesh.types.BMVert):
            return elem.index
    return None

def bmesh_sel_verts_history(bm):
    if bm.select_history:
        elem = bm.select_history[-1]
        return [elem.index for elem in bm.select_history if isinstance(elem, bmesh.types.BMVert)]
    return None

def calc_power(cpow): #defined also in surface_to_splines
    if cpow < 0:  # (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
        cpow = 1 + cpow * 0.5  # for negative map <-1,0> to <0.2, 1>
    else:
        cpow = 1 + 2 * cpow  # for positive map   <0, 1> to <1 , 5 >
    return cpow


def easing_cubic_ease_in_out(t, b=0, c=1, d=1):
    t /= d/2
    if (t < 1):
        return c/2*t*t*t + b
    t -= 2
    return c/2*(t*t*t + 2) + b


def easing_quad_ease_in_out(time,  begin = 0,  change = 1,  duration = 1): #change is like amp
    time /= duration/2
    if time < 1:
        return change / 2 * time * time + begin
    time -= 1
    return - change / 2 * (time*(time-2) - 1) + begin

def easing_sin_ease_in_out(time,  begin = 0,  change = 1,  duration = 1): #change is like amp
    return -change/2 * (math.cos(math.pi*time/duration) - 1) + begin

def round_to_1(x):
    return round(x, -int(floor(log10(abs(x)))))


CACHE_VERTS_WEIGHTS = []
USED_GROUPS = []
VERTS = []
# USED_GROUPS.update([group.group for vert in verts for group in vert.groups])
# CACHE_VERTS_WEIGHTS = [{group.group: group.weight for group in vert.groups} for vert in verts]

def create_weights_cache(obj, kd = None):
    global CACHE_VERTS_WEIGHTS, USED_GROUPS, VERTS
    if bpy.context.object.data.use_paint_mask_vertex or bpy.context.object.data.use_paint_mask:
        verts = {v for v in obj.data.vertices if v.select}
        new_verts = []
        if bpy.context.scene.wpt_enable_mirror:
            for vert in verts:
                _, mirror_vert_index, dist = kd.find(Vector((-vert.co[0], vert.co[1], vert.co[2]))) #co, vert_id, dist
                if dist < obj.wpt_search_dist:  # use mirrored verts, but without duplicates so set
                    new_verts.append(obj.data.vertices[mirror_vert_index])
        verts.update(set(new_verts))
        VERTS = list(verts)
    else:
        VERTS = [v for v in obj.data.vertices]

    CACHE_VERTS_WEIGHTS = {vert.index: {group.group: group.weight for group in vert.groups if group.weight} for vert in VERTS}
    USED_GROUPS = {}
    for v in VERTS:
        for g in v.groups:
            if not g.group in USED_GROUPS:
                USED_GROUPS[g.group] = []
            USED_GROUPS[g.group].append(v.index)


def restore_weights_from_cache(obj):
    global CACHE_VERTS_WEIGHTS, USED_GROUPS
    verts_ids = list(CACHE_VERTS_WEIGHTS.keys())
    for gr in obj.vertex_groups:  # remove all ver grous, cos eg. smooht may bleed new groups outside USED_GROUPS list
        gr.remove(verts_ids)

    for g_id, v_ids in USED_GROUPS.items(): # fater thatn addin one by one?
        obj.vertex_groups[g_id].add(v_ids, 0, "REPLACE")

    for vert, vert_cache in zip(VERTS, CACHE_VERTS_WEIGHTS.values()):
        for orig_g_id, w in  vert_cache.items():
            for g in vert.groups:
                if g.group == orig_g_id:
                    g.weight = w
                    break

        # vert.groups.foreach_set('weight', vert_cache.values()) #crashes...

        # for g_id, weight in vert_cache.items():
        # 	obj.vertex_groups[g_id].add([vert.index], weight, "REPLACE")




class EnumListLoop(object):
    def find_default_index(self, default):
        for i, e in enumerate(self.entries_list):
            if e == default:
                return i
        return 0

    def __init__(self, entries, default=0):
        self.entries_list = [e[0] for e in entries]
        if isinstance(default, int):
            self.index = default % len(self.entries_list)
        else:
            self.index = self.find_default_index(default)
        self.lock_looping = False

    def next(self):
        if not self.lock_looping:
            self.index = (self.index + 1) % len(self.entries_list)
        return self.entries_list[self.index]

    def prev(self):
        if not self.lock_looping:
            self.index = (self.index - 1) % len(self.entries_list)
        return self.entries_list[self.index]


class OperatorSettings:
    # Static member
    _settings = {}

    def save_settings(self):
        for d in dir(self.properties):
            if d in {'bl_rna', 'rna_type'}:
                continue
            try:
                self.__class__._settings[d] = self.properties[d]
            except KeyError:
                # catches __doc__ etc.
                continue

    def load_settings(self):
        # what exception could occur here??
        for d in self.__class__._settings:
            self.properties[d] = self.__class__._settings[d]


def get_avg_weight(face, w_lay, co, source_id):
    avg_weight = 0
    face_barycentric_w = poly_3d_calc([v.co for v in face.verts], co)  # get barycentric weights
    for i, vert in enumerate(face.verts):
        avg_weight += vert[w_lay][source_id] * face_barycentric_w[i] if source_id in vert[w_lay].keys() else 0
    return avg_weight


def get_baryc_vgroups_weights(face, w_lay, co, target_vg_ids=None):
    # this will be output groups ids
    face_barycentric_w = poly_3d_calc([v.co for v in face.verts], co)  # get barycentric weights

    if target_vg_ids:
        face_groups_li = {g for vert in face.verts for g in vert[w_lay].keys() if target_vg_ids.get(g) != None} # ignore vg that are not in mirrored_idx list
    else:
        face_groups_li = {g for vert in face.verts for g in vert[w_lay].keys()} # ignore vg that are not in mirrored_idx list
    avg_weight = {g_idx:0 for g_idx in face_groups_li}

    for i, vert in enumerate(face.verts):
        for g_idx in face_groups_li:
            avg_weight[g_idx] += vert[w_lay][g_idx] * face_barycentric_w[i] if g_idx in vert[w_lay].keys() else 0
    return avg_weight


def armature_deselect_all_bones(armature_obj):
    if bpy.app.version <  (5, 0, 0):
        for bone in armature_obj.data.bones:
            bone.select = False
    else:
        for pbone in armature_obj.pose.bones:
            pbone.select = False

def select_pbone(pose_bone, state: bool):
    if bpy.app.version <  (5, 0, 0):
        pose_bone.bone.select = state
    else:
        pose_bone.select = state


def is_vertex_group_used_for_deformation(obj, vgroup_name):
    aramtures = [modifier.object for modifier in obj.modifiers if modifier.type == 'ARMATURE' and modifier.object]
    if not aramtures:
        return False

    for arma in aramtures:
        bone = arma.data.bones.get(vgroup_name)
        if bone:
            return bone.use_deform

    return False


def get_deforming_vertex_groups(obj):
    deforming_groups = []

    aramtures = [modifier.object for modifier in obj.modifiers if modifier.type == 'ARMATURE' and modifier.object]
    if not aramtures:
        return deforming_groups

    for vgroup in obj.vertex_groups:
        for arma in aramtures:
            bone = arma.data.bones.get(vgroup.name)
            if bone and bone.use_deform:
                deforming_groups.append(vgroup.name)
                break

    return deforming_groups

def get_first_armature_target(obj):
    for mod in obj.modifiers:
        if mod.type=='ARMATURE':
            return mod.object
    return None

def get_first_armature_mod(obj):
    for mod in obj.modifiers:
        if mod.type=='ARMATURE':
            return mod
    return False

def get_armature_from_active_bone(context, obj):
    if context.active_pose_bone:
        armature_obj = context.active_pose_bone.id_data
    else:
        armature_obj = get_first_armature_target(obj)
    return armature_obj


def has_armature(obj):
    for mod in obj.modifiers:
        if mod.type == 'ARMATURE':
            return True
    return False


def replace_rl(letter):
    replacements = {'l': 'r', 'r': 'l', 'L': 'R', 'R': 'L'}
    return replacements.get(letter, letter)

def is_name_r_l(name):
    if len(name) < 3:
        return ''
    if re.findall("[\._][lrRL]$", name):  # (/Z )- ends with .r, _l etc
        return True
    if re.findall("[\._][lrRL][\._]", name):  # /there is .r., _l. somewhere etc
        return True
    return False


def get_mirrored_name(name):
    return bpy.utils.flip_name(name)
    # if len(name) < 3:
    #     return ''
    # match = re.findall("[\._][lrRL]$", name)  # (/Z) - ends with .r, _l etc  . Return list
    # if match:
    #     switched_suffix = match[-1].replace(match[-1][-1], replace_rl(match[-1][-1])) # r <-> l
    #     return re.sub("[\._][lrRL]$", switched_suffix, name)
    # else:
    #     match = re.findall("[\._][lrRL][\._]", name)  # /there is .r., _l. etc
    #     if not match: # there is no .[rlRL] in string
    #         return ''
    #     switched_suffix = match[-1].replace(match[-1][-2], replace_rl(match[-1][-2])) # r <-> l
    #     return re.sub("[\._][lrRL][\._]", switched_suffix, name)


def get_target_vgroups_ids(context, mode):
    if mode == 'BONE_SELECT':
        candidates = {pb.name:True for pb in context.selected_pose_bones}
    elif mode == 'DISABLED':
        return []
    elif mode == 'ACTIVE': # active vg - no bone..
        active_vg = context.active_object.vertex_groups.active
        return  [active_vg.index] if active_vg else []
    elif mode == 'ALL':
        return [vg.index for vg in context.active_object.vertex_groups if not vg.lock_weight]
    elif mode == 'BONE_DEFORM':
        # sel_arma = [o for o in context.selected_editable_objects if o.type == 'ARMATURE']
        sel_arma = [mod.object for mod in context.active_object.modifiers if mod.type=='ARMATURE' and mod.object]
        if sel_arma:
            # get all bones names from selected armatures list
            candidates = {pb.name:True for arma in sel_arma for pb in arma.data.bones if pb.use_deform}
        else:
            return []
    # NOTE: why not ignore vg.lock_weight? - cos we can mirror locked wg - they themselves are not affected
    return [vg.index for vg in context.active_object.vertex_groups if candidates.get(vg.name)] # output vg names that exist

@clearable_cache
def build_ids_to_mirrored_ids(context,obj,mode,symmetrize):
    """ Build mirrored vgroups ids dict - get_mirrored_vg_idx[vg.index] = mirror_vgroup.index
        get_mirrored_vg_idx[vg.index] = None - if mirror_vg is locked

    Args:
        context ():
        obj ():
        mode ():
        symmetrize ():

    Returns:

    """
    vgroups_for_mirror = get_target_vgroups_ids(context, mode)
    # filter armature bones by vertex groups belonging to active object
    # return [vg.index for vg in context.active_object.vertex_groups if candidates.get(vg.name) ] # and not vg.lock_weight - we can mirror locked wg

    # NOTE: build mirrored_vg[in_vg.index] = mirror_vgroup.index
    get_mirrored_vg_idx = {}  # get_mirrored_vg_idx[read_from.id] = write_to.idx
    if not vgroups_for_mirror:
        return

    if symmetrize=='FULL':   # FORCE ful symm
        for in_vg_id in vgroups_for_mirror:
            get_mirrored_vg_idx[in_vg_id] = in_vg_id # mirror to itself - e.g. spine bones
    else:   # same for SOFT and OFF
        for in_vg_id in vgroups_for_mirror:
            vg_name = obj.vertex_groups[in_vg_id].name
            is_name_l_r_type = is_name_r_l(vg_name)
            if not is_name_l_r_type: # must be non L/R vert group type
                get_mirrored_vg_idx[in_vg_id] = in_vg_id # mirror to itself - e.g. spine bones
            else:
                mirrored_vg_name = get_mirrored_name(vg_name)
                mirr_vg  = obj.vertex_groups.get(mirrored_vg_name)
                if mirr_vg :  # if mirrored vg exist
                    # NOTE: do not mirror into locked vg
                    get_mirrored_vg_idx[in_vg_id] = None if mirr_vg.lock_weight else mirr_vg.index
                else:  # copy gv and name it with mirrored name
                    vg = obj.vertex_groups.new(name=mirrored_vg_name) #changes active idx
                    get_mirrored_vg_idx[in_vg_id] = vg.index
    return get_mirrored_vg_idx

@clearable_cache
def build_ids_to_mirror_projected_ids(context,obj,mode,symmetrize):
    receiving_vgroups_for_mirror = get_target_vgroups_ids(context, mode)
    # NOTE: build mirrored_vg[in_vg.index] = mirror_vgroup.index
    get_mirrored_vg_idx = {}  # get_mirrored_vg_idx[write_to.id] = read_from.idx (swapped compared to normal mirror)
    if not receiving_vgroups_for_mirror:
        return

    for receiver_vg_id in receiving_vgroups_for_mirror:  # inverted compared to normal mirror
        in_vg = obj.vertex_groups[receiver_vg_id]
        if in_vg.lock_weight: # do not write to locked vg
            continue
        vg_name = obj.vertex_groups[receiver_vg_id].name
        is_name_l_r_type = is_name_r_l(vg_name)

        if not is_name_l_r_type: # must be non L/R vert group type
            get_mirrored_vg_idx[receiver_vg_id] = receiver_vg_id # mirror to itself - e.g. spine bones
        else:
            mirrored_vg_name = get_mirrored_name(vg_name)
            mirr_vg  = obj.vertex_groups.get(mirrored_vg_name)
               # FORCE ful symm
            if mirr_vg :  # if mirrored vg exist  # FULL symm -> receive weights from mirrored vg
                get_mirrored_vg_idx[mirr_vg.index] = mirr_vg.index if symmetrize=='FULL' else receiver_vg_id
            # else we have no mirrored vg to receive weights from

    return get_mirrored_vg_idx



def build_mesh_kd_tree(mesh):
    size = len(mesh.vertices)
    kd = kdtree.KDTree(size)
    for i, v in enumerate(mesh.vertices):
        kd.insert(v.co, i)
    kd.balance()
    return kd


def check_group_exist(obj,name):
    return name in obj.vertex_groups.keys()


def get_addon_name():
    return __package__.split(".")[0]


def addon_name_lowercase():
    return get_addon_name().lower()


def get_addon_preferences():
    return bpy.context.preferences.addons[get_addon_name()].preferences
