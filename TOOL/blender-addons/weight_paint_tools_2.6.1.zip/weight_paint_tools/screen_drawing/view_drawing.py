'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy
import gpu
import blf
import numpy as np
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix, Vector


shader_3d_uniform = gpu.shader.from_builtin('UNIFORM_COLOR')
shader_2d_uniform = gpu.shader.from_builtin('UNIFORM_COLOR') # old '2D_UNIFORM_COLOR'

class GlDrawing():
    """Common Operator methods for garment editing are defined here"""

    _handle_draw_verts = []
    _handle_draw_text = []
    enable_debug = False
    draw_color = (1.0, 0.5, 0.0, 0.8)

    def __init__(self):
        self._handle_draw_verts = []
        self._handle_draw_text = []
        self.enable_debug = False
        pass

    @staticmethod
    def __draw_mesh_px(self, vertices, face_ids, e_k):
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set("ALPHA")
        gpu.state.depth_test_set("NONE")
        # bgl.glEnable(bgl.GL_CULL_FACE) # XXX: no replacement?
        gpu.state.face_culling_set("BACK") # if bpy.app.version >= (3,5,0) else bgl.glCullFace(bgl.GL_BACK)
        batch_faces = batch_for_shader(shader_3d_uniform, 'TRIS', {"pos": vertices}, indices=face_ids )
        shader_3d_uniform.bind()
        shader_3d_uniform.uniform_float("color", self.draw_color[:-1] + (0.2,))
        batch_faces.draw(shader_3d_uniform)

        batch_edges = batch_for_shader(shader_3d_uniform, 'LINES', {"pos": vertices}, indices=e_k)
        shader_3d_uniform.bind()
        shader_3d_uniform.uniform_float("color",  self.draw_color[:-1] + (1.0,))
        batch_edges.draw(shader_3d_uniform)

        gpu.state.face_culling_set("NONE") # if bpy.app.version >= (3,5,0) else bgl.glDisable(bgl.GL_CULL_FACE)
        # gpu.state.depth_test_set("NONE") if bpy.app.version >= (3,5,0) else bgl.glDisable(bgl.GL_DEPTH_TEST)
        gpu.state.blend_set("NONE")

    @staticmethod
    def __draw_mesh_edges_px(self, vertices, indices):
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set("ALPHA")
        # bgl.glEnable(bgl.GL_CULL_FACE) # XXX: no replacement?
        gpu.state.face_culling_set("BACK") # if bpy.app.version >= (3,5,0) else bgl.glCullFace(bgl.GL_BACK)

        batch = batch_for_shader(shader_3d_uniform, 'LINES', {"pos": vertices}, indices=indices)
        shader_3d_uniform.bind()
        shader_3d_uniform.uniform_float("color", self.draw_color)
        batch.draw(shader_3d_uniform)

        gpu.state.depth_test_set("NONE")
        gpu.state.face_culling_set("NONE") # if bpy.app.version >= (3,5,0) else bgl.glDisable(bgl.GL_CULL_FACE)
        gpu.state.blend_set("NONE")

    @staticmethod
    def __draw_lines_px(self, data_id, mode = '3D'):
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set("ALPHA")
        line_data = data_id() if callable(data_id) else data_id #if function?
        # print(f"drawing pts line: {line_data}")
        if mode== '3D':
            gpu.state.depth_test_set("NONE")
            batch = batch_for_shader(shader_3d_uniform, 'LINES', {"pos": line_data})
            shader_3d_uniform.bind()
            shader_3d_uniform.uniform_float("color", self.draw_color)
            batch.draw(shader_3d_uniform)
            # bgl.glDisable(bgl.GL_DEPTH_TEST)
        else:
            batch = batch_for_shader(shader_2d_uniform, 'LINES', {"pos": line_data})
            shader_2d_uniform.bind()
            shader_2d_uniform.uniform_float("color", self.draw_color)
            batch.draw(shader_2d_uniform)

        gpu.state.blend_set("NONE")



    def __draw_text_lines_px(self, context, lines_id, left_margin=30, bottom_margin=20, width_override=False):
        h1_font_size = 19
        p_font_size = 22
        line_height_h1 = int(1.4*h1_font_size)
        line_height_p = int(1.4*p_font_size)
        font_id = 0

        left_pos = 40
        bottom_pos = 60

        text_line_data = lines_id(context) if callable(lines_id) else lines_id  # if function?
        if width_override:
            box_width = width_override
        else:
            max_string_len = len(max(text_line_data, key=lambda p: len(p[0]))[0])
            box_width = max_string_len * (0.55*p_font_size)
        self.__draw_text_bbox(width=box_width, height=len(text_line_data)*line_height_p+bottom_margin, left_pos=left_pos, bottom_pos=bottom_pos)

        accum_y_pos = bottom_pos + bottom_margin  # go down line by line from top
        blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
        for line in reversed(text_line_data):
            text, line_type = line
            font_size = h1_font_size if line_type == 'H1' else p_font_size
            if bpy.app.version >= (4,0,0):
                blf.size(font_id, font_size*0.8)
            else:
                blf.size(font_id, font_size, 60)

            blf.position(font_id, left_pos+left_margin, accum_y_pos, 0)
            blf.draw(font_id, text)
            if line_type == 'H1':
                accum_y_pos += line_height_h1
            else:
                accum_y_pos += line_height_p

    def __draw_text_bbox(self, width, height, left_pos, bottom_pos):
        '''  0  - 1
            |  / |
            2  - 3
        '''
        gpu.state.blend_set("ALPHA")
        vertices = ((left_pos, bottom_pos+height), (left_pos+width, bottom_pos+height),
                    (left_pos, bottom_pos), (left_pos+width, bottom_pos))
        indices = ((0, 1, 2), (2, 3, 1))
        batch = batch_for_shader(shader_2d_uniform, 'TRIS', {"pos": vertices}, indices=indices)

        shader_2d_uniform.bind()
        shader_2d_uniform.uniform_float("color", (0., 0., 0., 0.4))
        batch.draw(shader_2d_uniform)
        gpu.state.blend_set("NONE")


    def draw_mesh(self, mesh, draw_as = 'DEBUG'):
        if not self.enable_debug and not draw_as:
            return
        mesh.calc_loop_triangles()
        vertices = np.empty((len(mesh.vertices), 3), 'f')
        face_ids = np.empty((len(mesh.loop_triangles), 3), 'i')

        mesh.vertices.foreach_get( "co", np.reshape(vertices, len(mesh.vertices) * 3))
        mesh.loop_triangles.foreach_get("vertices", np.reshape(face_ids, len(mesh.loop_triangles) * 3))

        args = (self, vertices, face_ids, mesh.edge_keys)
        self._handle_draw_verts.append(bpy.types.SpaceView3D.draw_handler_add(self.__draw_mesh_px, args, 'WINDOW', 'POST_VIEW'))
        return self._handle_draw_verts[-1]

    def draw_lines(self, data_id, mode = '3D', draw_as = 'DEBUG'):
        if not self.enable_debug and draw_as == 'DEBUG':
            return
        args = (self, data_id, mode)
        if mode == '3D':
            self._handle_draw_verts.append(bpy.types.SpaceView3D.draw_handler_add(self.__draw_lines_px, args, 'WINDOW', 'POST_VIEW'))
        else:
            self._handle_draw_verts.append(bpy.types.SpaceView3D.draw_handler_add(self.__draw_lines_px, args, 'WINDOW', 'POST_PIXEL'))
        return self._handle_draw_verts[-1]

    def draw_mesh_preset(self, preset, mat=None, draw_as = 'DEBUG'):
        if not self.enable_debug and draw_as == 'DEBUG':
            return
        if mat == None:
            mat = Matrix.Identity(4)
        mat_np = np.array(mat, 'f')

        if preset == 'SPHERE':
            vertices = np.array([[0.,  0., -1., 1],
                [0.7236073, -0.5257253, -0.44721952, 1],
                [-0.27638802, -0.85064924, -0.44721985, 1],
                [-0.8944262,  0., -0.44721562, 1],
                [-0.27638802,  0.85064924, -0.44721985, 1],
                [0.7236073,  0.5257253, -0.44721952, 1],
                [0.27638802, -0.85064924,  0.44721985, 1],
                [-0.7236073, -0.5257253,  0.44721952, 1],
                [-0.7236073,  0.5257253,  0.44721952, 1],
                [0.27638802,  0.85064924,  0.44721985, 1],
                [0.8944262,  0.,  0.44721562, 1],
                [0.,  0.,  1., 1],
                [-0.16245556, -0.49999526, -0.8506544, 1],
                [0.42532268, -0.3090114, -0.8506542, 1],
                [0.26286882, -0.80901164, -0.52573764, 1],
                [0.85064787,  0., -0.5257359, 1],
                [0.42532268,  0.3090114, -0.8506542, 1],
                [-0.5257298,  0., -0.8506517, 1],
                [-0.6881894, -0.49999693, -0.5257362, 1],
                [-0.16245556,  0.49999526, -0.8506544, 1],
                [-0.6881894,  0.49999693, -0.5257362, 1],
                [0.26286882,  0.80901164, -0.52573764, 1],
                [0.95105785, -0.30901262,  0., 1],
                [0.95105785,  0.30901262,  0., 1],
                [0., -0.99999994,  0., 1],
                [0.5877856, -0.8090167,  0., 1],
                [-0.95105785, -0.30901262,  0., 1],
                [-0.5877856, -0.8090167,  0., 1],
                [-0.5877856,  0.8090167,  0., 1],
                [-0.95105785,  0.30901262,  0., 1],
                [0.5877856,  0.8090167,  0., 1],
                [0.,  0.99999994,  0., 1],
                [0.6881894, -0.49999693,  0.5257362, 1],
                [-0.26286882, -0.80901164,  0.52573764, 1],
                [-0.85064787,  0.,  0.5257359, 1],
                [-0.26286882,  0.80901164,  0.52573764, 1],
                [0.6881894,  0.49999693,  0.5257362, 1],
                [0.16245556, -0.49999526,  0.85065436, 1],
                [0.5257298,  0.,  0.8506517, 1],
                [-0.42532268, -0.3090114,  0.8506542, 1],
                [-0.42532268,  0.3090114,  0.8506542, 1],
                [0.16245556,  0.49999526,  0.85065436, 1]], 'f')
            # vertices = np.dot(vertices, mat_np)[:, :-1]  # mat @ verts
            vertices = np.einsum('ij,aj->ai', mat_np, vertices)[:, :-1]
            face_indices = [[0, 13, 12],
                    [1, 13, 15],
                    [0, 12, 17],
                    [0, 17, 19],
                    [0, 19, 16],
                    [1, 15, 22],
                    [2, 14, 24],
                    [3, 18, 26],
                    [4, 20, 28],
                    [5, 21, 30],
                    [1, 22, 25],
                    [2, 24, 27],
                    [3, 26, 29],
                    [4, 28, 31],
                    [5, 30, 23],
                    [6, 32, 37],
                    [7, 33, 39],
                    [8, 34, 40],
                    [9, 35, 41],
                    [10, 36, 38],
                    [38, 41, 11],
                    [38, 36, 41],
                    [36,  9, 41],
                    [41, 40, 11],
                    [41, 35, 40],
                    [35,  8, 40],
                    [40, 39, 11],
                    [40, 34, 39],
                    [34,  7, 39],
                    [39, 37, 11],
                    [39, 33, 37],
                    [33,  6, 37],
                    [37, 38, 11],
                    [37, 32, 38],
                    [32, 10, 38],
                    [23, 36, 10],
                    [23, 30, 36],
                    [30,  9, 36],
                    [31, 35,  9],
                    [31, 28, 35],
                    [28,  8, 35],
                    [29, 34,  8],
                    [29, 26, 34],
                    [26,  7, 34],
                    [27, 33,  7],
                    [27, 24, 33],
                    [24,  6, 33],
                    [25, 32,  6],
                    [25, 22, 32],
                    [22, 10, 32],
                    [30, 31,  9],
                    [30, 21, 31],
                    [21,  4, 31],
                    [28, 29,  8],
                    [28, 20, 29],
                    [20,  3, 29],
                    [26, 27,  7],
                    [26, 18, 27],
                    [18,  2, 27],
                    [24, 25,  6],
                    [24, 14, 25],
                    [14,  1, 25],
                    [22, 23, 10],
                    [22, 15, 23],
                    [15,  5, 23],
                    [16, 21,  5],
                    [16, 19, 21],
                    [19,  4, 21],
                    [19, 20,  4],
                    [19, 17, 20],
                    [17,  3, 20],
                    [17, 18,  3],
                    [17, 12, 18],
                    [12,  2, 18],
                    [15, 16,  5],
                    [15, 13, 16],
                    [13,  0, 16],
                    [12, 14,  2],
                    [12, 13, 14],
                    [13,  1, 14]]
            edges = [(0, 12), (1, 13), (2, 14), (1, 15), (5, 16), (0, 17), (3, 18), (0, 19), (4, 20), (5, 21), (1, 22), (10, 23), (2, 24), (6, 25), (3, 26), (7, 27), (4, 28), (8, 29), (5, 30), (9, 31), (6, 32), (7, 33), (8, 34), (9, 35), (10, 36), (6, 37), (11, 38), (7, 39), (8, 40), (9, 41), (2, 12), (0, 13), (1, 14), (5, 15), (0, 16), (3, 17), (2, 18), (4, 19), (3, 20), (4, 21), (10, 22), (5, 23), (6, 24), (1, 25), (7, 26), (2, 27), (8, 28), (3, 29), (9, 30), (4, 31), (10, 32), (6, 33), (7, 34), (8, 35), (9, 36), (11, 37), (10, 38), (11, 39), (11, 40), (11, 41), (38, 41), (36, 38),
                     (36, 41), (40, 41), (35, 41), (35, 40), (39, 40), (34, 40), (34, 39), (37, 39), (33, 39), (33, 37), (37, 38), (32, 37), (32, 38), (23, 36), (23, 30), (30, 36), (31, 35), (28, 31), (28, 35), (29, 34), (26, 29), (26, 34), (27, 33), (24, 27), (24, 33), (25, 32), (22, 25), (22, 32), (30, 31), (21, 30), (21, 31), (28, 29), (20, 28), (20, 29), (26, 27), (18, 26), (18, 27), (24, 25), (14, 24), (14, 25), (22, 23), (15, 22), (15, 23), (16, 21), (16, 19), (19, 21), (19, 20), (17, 19), (17, 20), (17, 18), (12, 17), (12, 18), (15, 16), (13, 15), (13, 16), (12, 14), (12, 13), (13, 14)]
            # args = (self, vertices, face_indices)
            args = (self, vertices, edges)
            # if not self._handle_draw_verts:
            self._handle_draw_verts.append(bpy.types.SpaceView3D.draw_handler_add(self.__draw_mesh_edges_px, args, 'WINDOW', 'POST_VIEW'))

        # if not self._handle_draw_text:
        #     self._handle_draw_text = bpy.types.SpaceView3D.draw_handler_add(self.draw_text, args, 'WINDOW', 'POST_PIXEL')


    def draw_text_lines(self, context, lines, left_margin=30, bottom_margin=20, width_override=False, draw_as = 'DEBUG'):
        if not self.enable_debug and draw_as == 'DEBUG':
            return
        args = (context, lines, left_margin, bottom_margin, width_override)
        self._handle_draw_text.append(bpy.types.SpaceView3D.draw_handler_add(self.__draw_text_lines_px, args, 'WINDOW', 'POST_PIXEL'))
        return self._handle_draw_text[-1]


    def disable_handlers(self):
        for _handle_draw_verts in self._handle_draw_verts:
            bpy.types.SpaceView3D.draw_handler_remove(_handle_draw_verts, 'WINDOW')
        for _handle_draw_text in self._handle_draw_text:
            bpy.types.SpaceView3D.draw_handler_remove(_handle_draw_text, 'WINDOW')
        self._handle_draw_verts.clear()
        self._handle_draw_text.clear()

    def disable_handler(self, handle = None):
        if handle:
            bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        if handle in self._handle_draw_verts:
            self._handle_draw_verts.remove(handle)
        if handle in self._handle_draw_text:
            self._handle_draw_text.remove(handle)
