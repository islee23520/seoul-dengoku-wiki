'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
#TODO: finish remaking Depth Range


bl_info = {
    "name": "Weight Paint Tools",
    "description": "Weight Paint Tools",
    "author": "Bartosz Styperek",
    "version": (2, 6, 1),
    "blender": (4, 2, 0),
    "location": "ctrl+X in Weight Paint Mode",
    "warning": "",
    "doc_url": "https://joseconseco.github.io/WeightPaintToolsDocs/",
    "tracker_url": "https://discord.gg/cxZDbqH",
    "category": "Mesh" }

# load and reload submodules
##################################

if "bpy" in locals():
    import importlib
    importlib.reload(view_drawing)
    importlib.reload(wt_ui_keys)
    importlib.reload(wpt_helpers)
    importlib.reload(modal_delta_set)
    importlib.reload(weight_gradient_modal)
    importlib.reload(weight_paint_tool)
    importlib.reload(draw_weights)
    importlib.reload(update_addon)
else:
    from .screen_drawing import view_drawing
    from . import wt_ui_keys
    from . import wpt_helpers
    from . import modal_delta_set
    from . import weight_gradient_modal
    from . import weight_paint_tool
    from . import draw_weights
    from . import update_addon


import bpy

from . import auto_load

auto_load.init()


def draw_vertg_remove(self, context):
    self.layout.operator_context = 'INVOKE_DEFAULT'
    self.layout.operator( "object.vertex_group_remove_unused", icon='X' )


import traceback

def register():
    try:
        auto_load.register()
    except:
        traceback.print_exc()
    bpy.types.Scene.verts_weight_copies = []
    bpy.types.Scene.wpt_enable_mirror = bpy.props.BoolProperty(name="Enable Mirror", description="Enable Mirror for all WPTools operations", default=True)
    bpy.types.Object.wpt_search_dist =  bpy.props.FloatProperty(name="delta", default=0.01, min=0.00001, max=10)
    bpy.types.MESH_MT_vertex_group_context_menu.prepend(draw_vertg_remove)

    wt_ui_keys.RegisterHotkeys()

    draw_weights.register_wp()


def unregister():
    draw_weights.unregister_wp()

    wt_ui_keys.UnRegisterHotkeys()
    del bpy.types.Scene.verts_weight_copies
    del bpy.types.Object.wpt_search_dist
    del bpy.types.Scene.wpt_enable_mirror
    bpy.types.MESH_MT_vertex_group_context_menu.remove(draw_vertg_remove)
    try:
        auto_load.unregister()
    except: traceback.print_exc()

