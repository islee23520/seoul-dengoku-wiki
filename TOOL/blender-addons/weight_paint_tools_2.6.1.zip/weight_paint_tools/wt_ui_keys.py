'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
# import sys
# dir = 'C:\\Users\\JoseConseco\\AppData\\Local\\Programs\\Python\\Python37\\Lib\\site-packages'
# if not dir in sys.path:
#     sys.path.append(dir )
# import ipdb

import bpy
import rna_keymap_ui
from .wpt_helpers import addon_name_lowercase
from .draw_weights import calculate_weights, g_vertex_sel_color

class WPT_MT_VerGroupToolPie(bpy.types.Menu):
    bl_idname = "WPT_MT_VerGroupToolPie"
    bl_label = "Vertex groups Tool Pie"

    def draw(self, context):

        layout = self.layout
        pie = layout.menu_pie()

        # 4 - LEFT
        pie.operator("wm.call_menu_pie", text="Weight Tools", icon='PREFERENCES').name = WPT_MT_VerGroupSubToolsPie.bl_idname

        # 6 - RIGHT
        # split = pie.split()
        box = pie.box()
        col = box.column()
        row = col.row(align=False)
        row.label(text='Set weights:')
        row = col.row(align=True)
        row.alignment = 'CENTER'
        weight_set = row.operator("paint.weight_set_wp", text='', icon='CANCEL')
        weight_set.mix_method = "REPLACE"
        weight_set.weight = -1.0

        weight_set = row.operator("paint.weight_set_wp", text = '0')
        weight_set.mix_method = "REPLACE"
        weight_set.weight = 0.0

        weight_set = row.operator("paint.weight_set_wp",text = '0.2')
        weight_set.mix_method = "REPLACE"
        weight_set.weight = 0.2

        weight_set = row.operator("paint.weight_set_wp",text = '0.5')
        weight_set.mix_method = "REPLACE"
        weight_set.weight = 0.5

        weight_set = row.operator("paint.weight_set_wp",text = '0.8')
        weight_set.mix_method = "REPLACE"
        weight_set.weight = 0.8

        weight_set = row.operator("paint.weight_set_wp",text = '1')
        weight_set.mix_method = "REPLACE"
        weight_set.weight = 1.0


        row = col.row(align=True)
        if bpy.app.version < (5, 0, 0):
            row.prop(context.scene.tool_settings.unified_paint_settings, 'weight', text = '')
        else:
            row.prop(context.scene.tool_settings.weight_paint.unified_paint_settings, 'weight', text = '')
        weight_set = row.operator("paint.pick_weight",text = '', icon='EYEDROPPER')
        weight_set = row.operator("paint.weight_set_wp",text = '', icon='WPAINT_HLT')
        weight_set.mix_method = "REPLACE"
        if bpy.app.version < (5, 0, 0):
            weight = context.scene.tool_settings.unified_paint_settings.weight
        else:
            weight = context.scene.tool_settings.weight_paint.unified_paint_settings.weight
        weight_set.weight = weight

        # 2 - BOTTOM

        split = pie.split()
        col = split.column(align=True)

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("object.transfer_weights", icon='PLUS')

        # row = col.row(align=True)
        # row.scale_y = 1.5
        # row.operator("object.symmetrize_vg", icon='ARROW_LEFTRIGHT')

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("paint.mirror_vg", icon='MOD_MIRROR')

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("paint.mirror_vg_project", icon='MOD_MIRROR')

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("object.project_weights", icon='PROP_PROJECTED')

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("object.interpolate_override", icon='PIVOT_MEDIAN')


        # 8 - TOP
        pie.operator("pose.select_active_vg_bone", icon='CONSTRAINT_BONE')


        # 7 - TOP - LEFT
        pie.separator()


        # 9 - TOP - RIGHT
        pie.operator("object.vertex_group_fill", icon='FILTER')



        # 1 - BOTTOM - LEFT
        split = pie.split()
        col = split.column(align=True)

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("object.copy_vg_weight", icon='COPY_ID')

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("object.paste_vg_weight", icon='PASTEDOWN')


        # 3 - BOTTOM - RIGHT
        split = pie.split()
        col = split.column(align=True)

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("object.define_delta", icon='ARROW_LEFTRIGHT')
        row = col.row(align=True)
        row.scale_y = 1.5
        mirror_str = 'Mirroring: ENABLED' if context.scene.wpt_enable_mirror else 'Mirroring: DISABLED'
        row.prop(context.scene, "wpt_enable_mirror", text= mirror_str,  emboss=True)


class WPT_MT_VerGroupSubToolsPie(bpy.types.Menu):
    bl_idname = "WPT_MT_VerGroupSubToolsPie"
    bl_label = "Vertex groups Sub Pie"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()

        # 4 - LEFT
        pie.operator('paint.levels_weights')
        # pie.operator('object.vertex_group_levels')


        # 6 - RIGHT
        # pie.operator('object.vertex_group_smooth')
        pie.operator('paint.smooth_weights')

        # 2 - BOTTOM
        pie.operator('object.vertex_group_limit_total', text='Limit Total')

        # 8 - TOP
        split = pie.split()
        col = split.column(align=True)

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator('object.weight_normalize_with_symmetry')

        # row = col.row(align=True)
        # row.scale_y = 1.5
        # row.operator('object.vertex_group_normalize', text='Normalize')

        # 7 - TOP - LEFT
        pie.operator('paint.draw_weight_gradient')
        # box = pie.box()
        # col = box.column(align=True)
        # row = col.row(align=True)
        # row.scale_y = 1.5
        # row.operator('paint.draw_weight_gradient')
        # row.prop(context.scene,'wpt_gradients', text='')


        # 9 - TOP - RIGHT
        pie.separator()

        # 1 - BOTTOM - LEFT
        clean = pie.operator('object.vertex_group_clean', text='Clean Vertex Groups')
        clean.group_select_mode = "ALL"
        clean.limit = 0.02

        # 3 - BOTTOM - RIGHT
        pie.separator()


##########################         Addon Prefernedces                ###############################################

class WeightToolPreferences(bpy.types.AddonPreferences):
    bl_idname = "weight_paint_tools"
    tabs: bpy.props.EnumProperty(name="Tabs", items=[("UPDATE", "Update", ""),
                                                     ("OVERLAY", "Weights Overlay", ""),
                                                     ("HOTKEYS", "Hotkeys", "")], default="UPDATE")
    update_exist: bpy.props.BoolProperty(name="Update Exist", description="There is new GroupPro update",  default=False)
    update_text: bpy.props.StringProperty(name="Update text",  default='')

    def DrawMeshUpdate(self, context):
        calculate_weights(bpy.context.evaluated_depsgraph_get())

    colorize_active_group: bpy.props.BoolProperty(name="Colorize Active Group", description="Colorize Active Group", default=True, update=DrawMeshUpdate)
    active_group_color: bpy.props.FloatVectorProperty(name="Active Group Color", description="Active Group Color", default=g_vertex_sel_color, min=0.0, max=1.0, subtype='COLOR', size=3, update=DrawMeshUpdate)


    def draw(self, context):

        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, "tabs", expand=True)
        box = layout.box()
        if self.tabs == "UPDATE":
            col = box.column()
            sub_row = col.row(align=True)
            sub_row.operator(addon_name_lowercase()+".check_for_update")
            split_lines_text = self.update_text.splitlines()
            for line in split_lines_text:
                sub_row = col.row(align=True)
                sub_row.label(text=line)
            sub_row.separator()
            sub_row = col.row(align=True)
            if self.update_exist:
                sub_row.operator(addon_name_lowercase()+".update_addon", text='Install latest version').reinstall = False
            else:
                sub_row.operator(addon_name_lowercase()+".update_addon", text='Reinstall current version').reinstall = True
            sub_row.operator(addon_name_lowercase()+".rollback_addon")
        elif self.tabs == "OVERLAY":
            col = box.column()
            col.prop(self, "colorize_active_group", toggle=True)
            if self.colorize_active_group:
                col.prop(self, "active_group_color")

        elif self.tabs == "HOTKEYS":
            col = box.column()
            wm = bpy.context.window_manager
            kc = wm.keyconfigs.user
            km = kc.keymaps['Weight Paint']
            col.context_pointer_set("keymap", km)
            kmi = get_hotkey_entry_item(km, 'wm.call_menu_pie', "WPT_MT_VerGroupToolPie")
            if kmi:
                rna_keymap_ui.draw_kmi(["ADDON", "USER", "DEFAULT"], kc, km, kmi, col, 0)

            kmi = get_hotkey_item(km, 'paint.loop_select_wp')
            if kmi:
                rna_keymap_ui.draw_kmi(["ADDON", "USER", "DEFAULT"], kc, km, kmi, col, 0)

            kmi = get_hotkey_item(km, 'paint.loop_select_extend_wp')
            if kmi:
                rna_keymap_ui.draw_kmi(["ADDON", "USER", "DEFAULT"], kc, km, kmi, col, 0)

            kmi = get_hotkey_item(km, 'paint.select_bone_wp', prop='extendSel', prop_val=False)
            if kmi:
                rna_keymap_ui.draw_kmi(["ADDON", "USER", "DEFAULT"], kc, km, kmi, col, 0)

            kmi = get_hotkey_item(km, 'paint.select_bone_wp', prop='extendSel', prop_val=True)
            if kmi:
                rna_keymap_ui.draw_kmi(["ADDON", "USER", "DEFAULT"], kc, km, kmi, col, 0)

            if km.is_user_modified:
                col.operator('preferences.keymap_restore', text="Reset Hotkeys")





def get_hotkey_entry_item(km, kmi_name, kmi_value):
    '''
    returns hotkey of specific type, with specific properties.name (keymap is not a dict, so referencing by keys is not enough
    if there are multiple hotkeys!)
    '''
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if km.keymap_items[i].properties.name == kmi_value:
                return km_item
    return None


def get_hotkey_item(km, source_kmi, prop=None, prop_val = None):
    km_item = [kmi for kmi in km.keymap_items if kmi.idname == source_kmi and (not prop or (hasattr(kmi.properties, prop) and getattr(kmi.properties, prop) == prop_val))]
    return km_item[0] if km_item else None




class WPT_OT_WT_ADD_HOTKEY(bpy.types.Operator):
    ''' Add hotkey entry '''
    bl_idname = "weighttool.add_hotkey"
    bl_label = "Addon Preferences Example"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        UnRegisterHotkeys()
        RegisterHotkeys()
        self.report({'INFO'}, "Hotkeys Reseted")
        return {'FINISHED'}


addon_keymaps = [] #put on out of register()


def RegisterHotkeys():
    '''AFAIK this is overrriden later by user set hotkey in keyconfigs.user.
    That is why this wont always reset do defautl hotkey'''
    wm = bpy.context.window_manager
    # ipdb.set_trace()
    kc = wm.keyconfigs.addon
    # km = wm.keyconfigs.addon.keymaps['Weight Paint']
    km = kc.keymaps.new(name='Weight Paint', space_type="EMPTY")

    kmi = km.keymap_items.new("paint.grow_select_wp", type='NUMPAD_PLUS', value='PRESS', ctrl=True)
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new("paint.shrink_select_wp", type='NUMPAD_MINUS', value='PRESS', ctrl=True)
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new("paint.select_linked_wp", type='L', value='PRESS', ctrl=True)
    addon_keymaps.append((km, kmi))

    #! colides with pose mode armature hide...
    # kmi = km.keymap_items.new("paint.hide_selected_wp", type='H', value='PRESS')
    # addon_keymaps.append((km, kmi))
    # kmi.properties.hide_mode = 'HIDE'

    # kmi = km.keymap_items.new("paint.hide_selected_wp", type='H', value='PRESS', alt=True)
    # addon_keymaps.append((km, kmi))
    # kmi.properties.hide_mode = 'REVEAL'

    # kmi = km.keymap_items.new("paint.hide_selected_wp", type='H', value='PRESS', shift=True)
    # addon_keymaps.append((km, kmi))
    # kmi.properties.hide_mode = 'ISOLATE'

    kmi = km.keymap_items.new("paint.weight_set_wp", type='K', value='PRESS', shift=True)
    kmi.properties.weight = -1

    addon_keymaps.append((km, kmi))

    # if 'paint.weight_set' in km.keymap_items.keys(): #disable default hotkey if exist
    #     km.keymap_items['paint.weight_set'].active = False

    kmi = km.keymap_items.new("paint.draw_weight_gradient", type='D', value='PRESS', ctrl=True)
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new("paint.loop_select_wp", type='RIGHTMOUSE', value='PRESS', alt=True)
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new("paint.loop_select_extend_wp", type='RIGHTMOUSE', value='PRESS', alt=True, shift=True)
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new("paint.select_bone_wp", type='RIGHTMOUSE', value='PRESS', ctrl=True)
    kmi.properties.extendSel = False
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new("paint.select_bone_wp", type='RIGHTMOUSE', value='PRESS', shift=True, ctrl=True)
    kmi.properties.extendSel = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS', ctrl=True)
    kmi.properties.name = "WPT_MT_VerGroupToolPie"
    addon_keymaps.append((km, kmi))



def UnRegisterHotkeys():
    # wm = bpy.context.window_manager
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
        # wm.keyconfigs.addon.keymaps.remove(km)
    addon_keymaps.clear()
    wm = bpy.context.window_manager

    km = wm.keyconfigs.addon.keymaps['Weight Paint']
    if 'paint.weight_set' in km.keymap_items.keys(): #disable default hotkey if exist
        km.keymap_items['paint.weight_set'].active = True


