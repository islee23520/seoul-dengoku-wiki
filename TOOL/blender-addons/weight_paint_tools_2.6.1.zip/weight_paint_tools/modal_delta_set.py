'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy
# import bgl
import gpu
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils
import numpy as np
from mathutils import Vector, Matrix
from .wpt_helpers import *
from .screen_drawing.view_drawing import GlDrawing

shader = gpu.shader.from_builtin('UNIFORM_COLOR')
circle_co = np.array([(0.0, 1.0, 0.0, 1.0), (-0.707, 0.707, 0.0, 1.0), (-1.0, 0.0, 0.0, 1.0), (-0.7071, -0.7071, 0.0, 1.0),
                      (0.0, -1.0, 0.0, 1.0), (0.7071, -0.7071, 0.0, 1.0), (1.0, 0.0, 0.0, 1.0), (0.7071, 0.7071, 0.0, 1.0)], 'f')

if bpy.app.version >= (3, 5, 0):
    vert_out = gpu.types.GPUStageInterfaceInfo("wpt_interface")
    vert_out.smooth('VEC4', "outPos")
    vert_out.smooth('VEC3', "pos")

    shader_info = gpu.types.GPUShaderCreateInfo()
    shader_info.push_constant('MAT4', "viewProjectionMatrix")
    shader_info.push_constant('VEC4', "ucol")
    shader_info.push_constant('FLOAT', "bias_z")
    shader_info.vertex_in(0, 'VEC3', "position")
    shader_info.vertex_out(vert_out)
    shader_info.fragment_out(0, 'VEC4', "FragColor")

    shader_info.vertex_source(
    """
    void main()
    {
        pos = position;
        outPos = viewProjectionMatrix * vec4(position, 1.0f);
        outPos.z = outPos.z - 0.0005*bias_z/outPos.z; // counter w division for shift
        gl_Position = outPos;
    }
    """
    )

    shader_info.fragment_source(
    """
    void main()
    {
        FragColor = vec4(ucol);
    }
    """
    )

    shader_custom = gpu.shader.create_from_info(shader_info)
    del vert_out
    del shader_info
else:
    vertex_shader = '''
        uniform mat4 viewProjectionMatrix;

        in vec3 position;
        out vec3 pos;

        void main()
        {
            pos = position;
            gl_Position = viewProjectionMatrix * vec4(position, 1.0f);
        }
    '''

    fragment_shader = '''
        uniform vec4 ucol;

        in vec3 pos;
        out vec4 fragColor;

        void main()
        {
            fragColor = vec4(ucol);
        }
    '''

    shader_custom = gpu.types.GPUShader(vertex_shader, fragment_shader)


def draw_verts_px(self, context):
    theme = bpy.context.preferences.themes['Default']
    g_vertex_size = theme.view_3d.vertex_size

    g_rv3d = context.region_data
    obj_size = context.object.dimensions.length
    # view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    # ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    viewDir = g_rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))

    # dot_view_normal = np.einsum('j,ij->i',viewDir,face_normals)
    matrix = bpy.context.region_data.perspective_matrix

    gpu.state.point_size_set(g_vertex_size+2)
    # bgl.glEnable(bgl.GL_CULL_FACE)
    # bgl.glCullFace(bgl.GL_BACK)
    gpu.state.depth_test_set("LESS")
    # bgl.glDepthRange(0, 0.9996)  # TODO: move to gpu module
    # view_dir_vec = g_rv3d.view_rotation * Vector((0.0, 0.0, -1.0))
    # face_dot = np.einsum('j,ij->i',np.array(view_dir_vec),face_normals).tolist()
    # transformed_verts = [obj.matrix_world*v.co for v in mesh.vertices]

    right_verts = self.mesh_verts[self.paired_verts_mask & self.right_vert_mask]
    left_verts = self.mesh_verts[self.paired_verts_mask & self.left_vert_mask]

    empty_left = self.mesh_verts[~self.paired_verts_mask & self.right_vert_mask]
    empty_right = self.mesh_verts[~self.paired_verts_mask & self.left_vert_mask]

    if right_verts.size:
        batch = batch_for_shader(shader_custom, 'POINTS', {"position": right_verts})
        shader_custom.bind()
        shader_custom.uniform_float("viewProjectionMatrix", matrix)
        # shader_custom.uniform_float("color", (0, 0.9, 0, 1))
        shader_custom.uniform_float("bias_z", obj_size) # hack replaces GL_POLYGON_OFFSET_FILL
        shader_custom.uniform_float("ucol", (0, 0.9, 0, 1))
        batch.draw(shader_custom)

    if left_verts.size:
        batch = batch_for_shader(shader_custom, 'POINTS', {"position": left_verts})
        shader_custom.bind()
        shader_custom.uniform_float("viewProjectionMatrix", matrix)
        # shader_custom.uniform_float("color", (0.9, 0, 0, 1))
        shader_custom.uniform_float("bias_z", obj_size) # hack replaces GL_POLYGON_OFFSET_FILL
        shader_custom.uniform_float("ucol", (0.9, 0, 0, 1))
        batch.draw(shader_custom)


    # NOTE: draw circles for not matched verts
    # circle_edge_keys = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7), (0, 7)]
    quat_rot = Vector((0, 0, 1)).rotation_difference(viewDir)
    rot_mat = quat_rot.to_matrix().to_4x4()
    # obj.matrix_basis == (Matrix.Translation(obj.location) @ obj.rotation_quaternion.to_matrix().to_4x4() @ get_scale_mat(obj.scale))

    for center in empty_right:
        mat_loc = Matrix.Translation(center).to_4x4()
        batch_circle = batch_for_shader(shader_custom, 'LINE_LOOP', {"position": self.draw_circle_co[:, :-1]})  # , indices=circle_edge_keys
        shader_custom.bind()
        shader_custom.uniform_float("viewProjectionMatrix", matrix@mat_loc@rot_mat)
        shader_custom.uniform_float("ucol", (1, 0, 0, 1))
        shader_custom.uniform_float("bias_z", obj_size) # hack replaces GL_POLYGON_OFFSET_FILL
        batch_circle.draw(shader_custom)

    for center in empty_left:
        mat_loc = Matrix.Translation(center).to_4x4()
        batch_circle = batch_for_shader(shader_custom, 'LINE_LOOP', {"position": self.draw_circle_co[:, :-1]})  # , indices=circle_edge_keys
        shader_custom.bind()
        shader_custom.uniform_float("viewProjectionMatrix", matrix@mat_loc@rot_mat)
        shader_custom.uniform_float("ucol", (0, 1, 0, 1))
        shader_custom.uniform_float("bias_z", obj_size) # hack replaces GL_POLYGON_OFFSET_FILL
        batch_circle.draw(shader_custom)

    # for center in coords_l:
    #     mat_loc = Matrix.Translation(center).to_4x4()
    #     circle_co_trans = np.einsum('ij,aj->ai', np.array(mat_loc@rot_mat, 'f'), self.draw_circle_co)[:, :-1]
    #     batch_circle = batch_for_shader(shader, 'LINE_LOOP', {"pos": circle_co_trans})  # , indices=circle_edge_keys
    #     shader.bind()
    #     shader.uniform_float("color", (1, 1, 0, 1))
    #     batch_circle.draw(shader)

    # restore opengl defaults
    # bgl.glDepthRange(0, 1.0)
    # bgl.glDisable(bgl.GL_CULL_FACE)
    gpu.state.depth_test_set("NONE")
    gpu.state.point_size_set(1)
    # bgl.glDisable(bgl.GL_BLEND)

    # bpy.data.meshes.remove(mesh)





class WPT_OT_DrawDelta(bpy.types.Operator, GlDrawing):
    bl_idname = "object.define_delta"
    bl_label = "Symmetry Search Distance"
    bl_description = "Set symmetry searcj \'Distance\' parameter (per object)."\
                    "\nThe bigger the value, the more symmetrical verts pairs will be found.\n" \
                    "Too big value may lead to incorrect results, though"
    bl_options =  {"REGISTER","UNDO"}

    copied_v_count = 0

    paired_verts_mask = []
    mesh_verts = []

    @classmethod
    def poll(cls, context):
        return context.active_object.type == 'MESH'

    def text_lines_data(self, context):
        lines = []
        lines.append([f"(Shift)+MMB Search Distance: {round_to_1(context.active_object.wpt_search_dist)}", 'p'])
        lines.append([f"Mirrored/Total Verts: {self.copied_v_count}/{self.vcount}", 'p'])
        return lines


    def reset_draw_method(self, context):
        context.space_data.overlay.show_xray_bone = self.draw_state['back_xray']
        if self.armature_obj:
            self.armature_obj.show_in_front = self.draw_state['arma_draw_back']
        context.object.data.use_paint_mask = self.draw_state['use_paint_mask']
        context.object.data.use_paint_mask_vertex = self.draw_state['use_paint_mask_vertex']
        context.space_data.overlay.show_paint_wire = self.draw_state['show_paint_wire']

    def modal(self, context, event):
        obj = context.active_object
        if event.type in ('WHEELUPMOUSE','PAGE_UP') and event.value == 'PRESS':  # page up hack for MAC:
            if event.shift:
                # detect when log10(0.001) - is close to round number
                # then floor(log10(obj.wpt_search_dist)) will be 0.1 to weak for increasing wp_delta, so we *=2 instead
                if abs(round(log10(obj.wpt_search_dist)) - log10(obj.wpt_search_dist)) < 1.0e-4:  #detect when log10(0.001) - is close to round number
                    obj.wpt_search_dist *= 2
                else:
                    obj.wpt_search_dist += pow(10,floor(log10(obj.wpt_search_dist)))
            else:
                obj.wpt_search_dist *= 10
            # obj.wpt_search_dist = round_to_1(obj.wpt_search_dist)
            self.draw_circle_co = np.copy(circle_co)
            self.draw_circle_co[:, :-1] = self.obj_scale * obj.wpt_search_dist * self.draw_circle_co[:, :-1]
            self.find_mirrored_verts(context)
            context.area.tag_redraw()

        elif event.type in ('WHEELDOWNMOUSE','PAGE_DOWN') and event.value == 'PRESS':
            if event.shift:
                # detect when log10(0.001) - is close to round number
                # then floor(log10(obj.wpt_search_dist)) almost equal wp_delta so diff old_wp - new_wp == 0, so we do *=0.9 instead
                if abs(round(log10(obj.wpt_search_dist)) - log10(obj.wpt_search_dist)) < 1.0e-4:
                    obj.wpt_search_dist *= 0.9
                else:
                    obj.wpt_search_dist -= pow(10,floor(log10(obj.wpt_search_dist)))
            else:
                obj.wpt_search_dist /= 10

            self.draw_circle_co = np.copy(circle_co)
            self.draw_circle_co[:, :-1] = self.obj_scale * obj.wpt_search_dist * self.draw_circle_co[:, :-1]
            # obj.wpt_search_dist = round_to_1(obj.wpt_search_dist)
            self.find_mirrored_verts(context)
            context.area.tag_redraw()

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.report({'INFO'}, 'CANCELLED')
            self.disable_handlers()
            self.reset_draw_method(context)
            context.area.tag_redraw()
            return {'CANCELLED'}

        elif event.type in {'RET','LEFTMOUSE'}:
            self.disable_handlers()
            context.active_object.wpt_search_dist = round_to_1(context.active_object.wpt_search_dist)
            self.report({'INFO'}, 'Delta set to: ' + str(round_to_1(context.active_object.wpt_search_dist)))
            self.reset_draw_method(context)
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}


    def find_mirrored_verts(self, context):
        active_obj = context.active_object
        mesh = active_obj.data
        kd = self.kd
        vertCount = len(mesh.vertices)
        self.copied_v_count = 0

        self.paired_verts_mask = np.zeros(vertCount, dtype=bool)
        # searched_verts = [v for v in mesh.vertices if v.co[0]] # if self.search_right_side else [v for v in mesh.vertices if v.co[0] < -0.001]
        for vert in mesh.vertices:
            co, mirror_vert_index, dist = kd.find(Vector((-vert.co[0],vert.co[1],vert.co[2])))
            if dist < active_obj.wpt_search_dist:  # delta
                self.paired_verts_mask[vert.index]=True
                self.copied_v_count +=1



    def invoke(self, context, event):
        if context.active_object and context.active_object.type=='MESH':
            #* set nice drawing  method
            self.draw_state = {}
            self.draw_state['back_xray'] = context.space_data.overlay.show_xray_bone

            self.armature_obj = context.active_pose_bone.id_data if context.active_pose_bone else None
            if self.armature_obj:
                self.draw_state['arma_draw_back'] = self.armature_obj.show_in_front
                self.armature_obj.show_in_front = False

            self.draw_state['use_paint_mask'] = context.object.data.use_paint_mask
            self.draw_state['use_paint_mask_vertex'] = context.object.data.use_paint_mask_vertex
            self.draw_state['show_paint_wire'] = context.space_data.overlay.show_paint_wire

            context.space_data.overlay.show_xray_bone = False
            context.object.data.use_paint_mask = False
            context.object.data.use_paint_mask_vertex = False

            context.space_data.overlay.show_paint_wire = True


            active_obj = context.active_object
            mesh = active_obj.data

            cnt = len(mesh.vertices)

            self.vcount = cnt
            self.paired_verts_mask = np.zeros(cnt, dtype=bool)
            self.obj_scale = (active_obj.scale.x + active_obj.scale.y + active_obj.scale.z)/3

            verts_co = np.zeros((cnt*3), dtype=np.float16)
            mesh.vertices.foreach_get("co", verts_co)
            verts_co.shape = (cnt, 3)
            verts_co_4d = np.ones(shape=(cnt, 4), dtype=np.float16)
            verts_co_4d[:,:-1] = verts_co  # cos v (x,y,z,1) - point,   v(x,y,z,0)- vector

            # verts_normal = np.zeros((vertCount*3), dtype=np.float16)
            # mesh.vertices.foreach_get("normal", verts_normal[:])
            # verts_normal.shape = (vertCount, 3)
            # verts_normal_4d = np.zeros(shape=(vertCount, 4), dtype=np.float16)
            # verts_normal_4d[:,:-1]= verts_normal

            obj_matrix_world = np.array(active_obj.matrix_world, 'f')
            self.mesh_verts = np.einsum('ij,aj->ai', obj_matrix_world, verts_co_4d)[:, 0:-1]  # +verts_normal*objBBoxSize*0.001)

            self.draw_circle_co = np.copy(circle_co)
            self.draw_circle_co[:, :-1] = self.obj_scale * active_obj.wpt_search_dist * self.draw_circle_co[:, :-1]

            self.right_vert_mask = verts_co[:, 0] > 0.001
            self.left_vert_mask = verts_co[:, 0] < -0.001

            # bpy.data.meshes.remove(mesh)
            self.kd = build_mesh_kd_tree(active_obj.data)

            self.find_mirrored_verts(context)
            args = (self, context)
            self._handle_draw_verts.append(bpy.types.SpaceView3D.draw_handler_add(draw_verts_px, args, 'WINDOW', 'POST_VIEW'))

            self.draw_text_lines(context, self.text_lines_data, draw_as='UI')
            context.area.tag_redraw()
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        self.report({'WARNING'}, "No active object, could not finish")
        return {'CANCELLED'}





