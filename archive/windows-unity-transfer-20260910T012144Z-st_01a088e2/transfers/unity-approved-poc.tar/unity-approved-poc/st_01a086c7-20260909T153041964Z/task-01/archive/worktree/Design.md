# 《잔선: 서울》 Design.md — POC UI 시각 계약

상태: 2026-09-06 개정 — UI 프레임워크를 uGUI로 고정(소유자 결정, [Intent](Intent.md) 참조). 구현·캡처·검수는 이 문서를 기준으로 한다.
대상 해상도: `1280×720`, `1920×1080` (16:9). uGUI(Canvas) 전용. 텍스트는 TextMeshPro(TMP).

---

## 1. 시각 테제 (Visual Thesis)

붕괴 이후 서울 지하철은 네온 사이버펑크가 아니라 **젖은 콘크리트, 꺼진 안내판, 비상 전원, 녹슨 선로, 손때 묻은 노선도**다.

- 빛: 차가운 비상등(청백) + 드문 신호 적황. 스펙큘러 하이라이트 최소화.
- 면: 무광 금속, 마모된 타일, 흐릿한 유리. 그라데이션은 1–2 stop만.
- 선: 노선도 문법 — 직교·45° 폴드, 역 원점, 구간 굵기. UI 구분선도 같은 두께 체계.
- 색 의미: 노선·상태·위험만 채도를 쓰고, 장식 네온·이모지·글리치 오버레이 금지.
- 톤: 조용한 긴장. “살아남기 위한 행정” 느낌. 과장된 호러·히어로 포스터 금지.

거부 목록: generic neon sci-fi, 이모지, 스크린샷 붙여넣기 페이크, `Button1`/`TODO` 프로그래머 placeholder, 가독 불가 장식 텍스트.

---

## 2. 디자인 토큰

### 2.1 색 (sRGB hex, uGUI 스타일 토큰)

| 토큰 | 값 | 용도 |
|---|---|---|
| `--bg-void` | `#0B111C` | 전체 배경 |
| `--bg-panel` | `#141C2A` | 패널·카드 |
| `--bg-panel-raised` | `#1B2536` | 호버·선택 면 |
| `--bg-well` | `#0E1622` | 격자·입력 우물 |
| `--stroke-quiet` | `#2A3548` | 기본 테두리 |
| `--stroke-focus` | `#C9A227` | 포커스 링 (신호 황) |
| `--stroke-danger` | `#8B3A3A` | 위험·패배 |
| `--text-primary` | `#E6EAF0` | 본문·제목 |
| `--text-secondary` | `#9AA6B2` | 보조 라벨 |
| `--text-muted` | `#6B7684` | 비활성 |
| `--accent-line` | `#3D7EA6` | 노선·진행 (지하철 청) |
| `--accent-safe` | `#3F6B54` | 우회·안전 |
| `--accent-talk` | `#5B6B8A` | 교섭 |
| `--accent-fight` | `#8B4A3A` | 전투 |
| `--signal-live` | `#C9A227` | 현재 단계·활성 역 |
| `--grid-line` | `#243044` | 전투 격자 |
| `--ally-cell` | `#2A4A5C` | 아군 칸 |
| `--foe-cell` | `#5C2A2A` | 적 칸 |

### 2.2 간격·반경·선

| 토큰 | 720p | 1080p | 비고 |
|---|---|---|---|
| `--space-1` | 4 | 6 | 아이콘 갭 |
| `--space-2` | 8 | 12 | 컴포넌트 내부 |
| `--space-3` | 16 | 24 | 카드 패딩 |
| `--space-4` | 24 | 36 | 섹션 갭 |
| `--space-5` | 40 | 56 | 화면 여백 |
| `--radius-sm` | 2 | 3 | 칩 |
| `--radius-md` | 4 | 6 | 카드·버튼 |
| `--stroke-w` | 1 | 1–2 | 기본 테두리 |
| `--focus-w` | 2 | 3 | 포커스 링 |

### 2.3 타이포그래피 (한국어 우선)

| 역할 | 720p | 1080p | 두께 | 용도 |
|---|---|---|---|---|
| Display | 36 | 48 | Medium | 타이틀 로고 타이포 |
| Title | 24 | 32 | Medium | 화면 제목 |
| Section | 18 | 22 | Medium | 패널 헤더 |
| Body | 15 | 18 | Regular | 본문·카드 |
| Caption | 12 | 14 | Regular | 보조·메타 |
| MonoMeta | 12 | 14 | Regular | tick·hash·좌표 (숫자 폭 안정) |

규칙:

- 런타임 폰트: 플랫폼 기본 CJK 폴백(macOS Apple SD Gothic Neo / 시스템 산돌) — 커스텀 폰트 에셋은 Todo 13.
- CJK 줄바꿈: 단어 중간 강제 끊기 금지 대신 **어절 단위**, 조사 고아 1글자 허용. 카드 제목은 2줄 클램프.
- 자간: 본문 0, Display +2%. 영문 약어(SRPG, POC)는 본문 크기 유지.
- 색 대비: 본문 `text-primary` on `bg-panel` ≥ 4.5:1 목표. `text-muted`는 비활성에만.

---

## 3. 레이아웃 그리드

### 3.1 1280×720

- 안전 여백: 24px.
- 타이틀: 세로 중앙 스택 (로고 영역 280×120, 액션 열 320).
- 캠페인: 상단 스테이지 레일 64px, 좌 노선 360, 우 상세 860.
- 전투: 좌 HUD 280, 중앙 격자 최대 5×5 셀(셀 64), 우 로그 280.
- 정산: 중앙 카드 520 폭.

### 3.2 1920×1080

- 안전 여백: 40px.
- 동일 비율 스케일. 격자는 셀 96. 레일 96px.
- 가로 확장은 여백·카드 max-width로 흡수하고 본문 줄길이는 68자에 가깝게 유지.

### 3.3 공통

- 루트는 `flex-grow: 1`, 전체 화면. 스크롤은 조우 카드 목록·전투 로그만.
- 모달은 쓰지 않는다. 조우/정산은 같은 gameplay document 내 패널 전환.

---

## 4. 재사용 프리미티브와 상태

| 이름 | 요소 | 상태 |
|---|---|---|
| `jk-panel` | 면+stroke | default |
| `jk-button` | 버튼 | default / hover / focus / pressed / disabled |
| `jk-button--primary` | Start·확정 | 위 + accent-line 하단 2px |
| `jk-button--danger` | 전투 선택 | accent-fight stroke |
| `jk-chip` | 스테이지·역 | idle / current / done / locked |
| `jk-card` | 조우 선택 | idle / focus / selected |
| `jk-rail` | 가로 스테이지 레일 | — |
| `jk-route` | 세로/가로 역 연결 | node current/adjacent/dim |
| `jk-grid` | 전투 격자 | cell empty/ally/foe/focus |
| `jk-meter` | HP/사기/재충전 | fill 0–100% 또는 Core tick 값 |
| `jk-meta` | tick·hash | mono |

포커스: 항상 `stroke-focus` 링. 키보드만으로 모든 1차 액션 도달.

---

## 5. 화면 계약

### 5.1 MainTitle (`main-title-root`)

- 필수 이름: `main-title-root`, `main-title-mark`, `main-title-start`.
- Start는 기존 공개 FSM `ApplicationFlowCoordinator.OpenFoundationAsync`만 호출. 씬 직접 로드 금지.
- 카피: 제품명 《잔선: 서울》, 한 줄 피치(짧은 보조). 테스트는 문구를 고정하지 않고 **요소 존재·액션·FSM**만 검증.
- 배경: void + 희미한 노선 폴드(uGUI 기하, 이미지 텍스처 의존 없음).

### 5.2 Gameplay document (`gameplay-root`) — Foundation lease

한 active lease당 **Canvas 하나**. 패널 활성 전환으로 단계 표현.

| 패널 | 이름 | 스냅샷 소스 |
|---|---|---|
| 스테이지 레일 | `stage-rail`, `stage-base-prep` … `stage-base-ready` | `CampaignStage` 6단 |
| 노선 | `route-rail`, `station-Yeongdeungpo`, `station-Sindorim`, `station-Guro` | `RouteGraph` + `CampaignState.Node` |
| 조우 선택 | `encounter-choices`, `choice-negotiate`, `choice-bypass`, `choice-combat` | `CampaignStage.Resolution` |
| 전투 | `battle-hud`, `battle-grid`, `battle-cell-{x}-{y}`, `battle-hp`, `battle-morale`, `battle-reinforcement-forecast`, `card-general-recharge`, `battle-play-pause` | `BattleSimState` + `BattleSessionDriver.Paused` |
| 정산·복귀 | `settlement-panel`, `settlement-outcome`, `return-action` | settlement receipt fields |

스냅샷은 동일 seed/state에 대해 요소 이름 집합·current 표시·그리드 점유가 결정론적이어야 한다.

### 5.3 코어 루프 액션 (Todo 12)

- Start → Foundation lease.
- 출정 → 역 이동 → 조우 → 해결 → 교섭/우회/전투 → 정산 → 복귀는 scoped `PocCoreLoopController`가 Core API로 처리한다.
- 전투 중에는 노선 패널을 숨겨 HUD·5×5 격자·전투 기록의 가로 공간을 확보하고 정산 시 복원한다.

---

## 6. 키보드·접근성

| 순서 | MainTitle | Gameplay |
|---|---|---|
| 1 | `main-title-start` | `stage-rail` 내 current chip (표시만, 탭 스킵 가능) |
| 2 | — | 가시 역 노드 (current 우선) |
| 3 | — | 가시 조우 카드  Neg → Bypass → Combat |
| 4 | — | `formation-swap-front` → `edit-formation` → 카드 → `battle-play-pause` |
| 5 | — | `return-action` |

- Tab / Shift+Tab 순환. Enter·Space 활성화.
- 포커스 가능 요소만 `focusable`. 장식 라벨은 제외.
- 색만으로 상태 구분 금지: current chip은 하단 2px signal 바 + `aria` 대응 가능한 name 접미사 `-current` 클래스.

---

## 7. 모션

- 허용: 120–180ms ease-out 페이드/슬라이드(패널 전환), 포커스 링 즉시.
- 금지: 루프 네온 펄스, 카메라 흔들림, 전투 이펙트 파티클(Todo 13+).
- 결정론 캡처 중에는 모션 0 (uGUI 애니메이션 비활성 상태 `jk-motion-off`).

---

## 8. 에셋 규칙

- UI 기하·색은 2절 토큰. 래스터 필수 시에만 승격 텍스처, BOM fail-closed.
- 프로그래머 placeholder 텍스처·임시 이모지 폰트 금지.
- 프리팹·스타일 경로는 `Assets/Janseon/Foundation/UI/` 고정. 누락 시 lease readiness 실패.
- 씬 YAML 손편집 금지. Builder/`AssetDatabase`만.

---

## 9. 수용된 부채 (Accepted Debt)

- 커스텀 한글 폰트·아이콘 세트는 Todo 13.
- 전투 입력은 전투 전 진형 교대, 카드 사용, 일시정지/재개로 제한한다. 개별 유닛 직접 이동과 턴/AP 입력은 현재 계약이 아니다.
- 역사 3D/캐릭터 메시는 Todo 14–16. 본 계약은 UI 평면만.
- PanelSettings는 단일 공유 에셋. 테마 런타임 스위치 없음.

---

## 10. 캡처 매트릭스

| ID | 화면 | 상태 | 해상도 | 파일 stem |
|---|---|---|---|---|
| C1 | MainTitle | idle focus Start | 1280×720 | `main-title-1280x720` |
| C2 | MainTitle | idle focus Start | 1920×1080 | `main-title-1920x1080` |
| C3 | Route+Stage | BasePrep @ Yeongdeungpo | 1280×720 | `campaign-route-stage-1280x720` |
| C4 | Route+Stage | 동일 | 1920×1080 | `campaign-route-stage-1920x1080` |
| C5 | Encounter | Resolution choices | 1280×720 | `encounter-choices-1280x720` |
| C6 | Encounter | 동일 | 1920×1080 | `encounter-choices-1920x1080` |
| C7 | Battle | Open grid HUD | 1280×720 | `battle-state-1280x720` |
| C8 | Battle | 동일 | 1920×1080 | `battle-state-1920x1080` |
| C9 | Settlement | applied + return | 1280×720 | `settlement-return-1280x720` |
| C10 | Settlement | 동일 | 1920×1080 | `settlement-return-1920x1080` |

각 receipt: Unity `6000.7.0a5`, seed/state/hash, 실행 시작 시 고정한 실제 HEAD와 source fingerprint, 해상도, stem. 실행 중 source/HEAD 변동과 불일치 receipt는 실패한다.

저장 위치는 `JANSEON_CAPTURE_DIR` 절대 경로로 분리한다. 미지정 시 기존 `.omo/evidence/unity-poc-core-loop/task-11-ui-toolkit/captures/`를 사용한다. 검증기는 `--head`와 `--source-fingerprint`로 의도한 소스 신원을 전달받아 PNG bytes와 receipt를 대조한다.

---

## 11. 안정 요소 이름 (기계 계약)

```
main-title-root
main-title-mark
main-title-start
gameplay-root
stage-rail
stage-base-prep
stage-expedition
stage-encounter
stage-resolution
stage-settlement
stage-base-ready
route-rail
station-Yeongdeungpo
station-Sindorim
station-Guro
encounter-choices
choice-negotiate
choice-bypass
choice-combat
battle-hud
battle-grid
battle-cell-{x}-{y}   # x,y in 0..4
battle-hp
battle-morale
battle-reinforcement-forecast
card-general-recharge
card-general-use
formation-swap-front
formation-selection
edit-formation
battle-play-pause
settlement-panel
settlement-outcome
return-action
```

이 이름 집합이 스냅샷·테스트·캡처의 단일 출처다. 문구 리터럴은 테스트하지 않는다.

## 12. 검수 소품의 현재 연결

Foundation의 여섯 역사 소품은 동일 화면 lease의 카메라가 RenderTexture로 렌더링하고 노선 패널에 표시한다. 프리뷰는 런타임 3D 모델·재질을 사용하며 정적 screenshot 대체물이 아니다. 카메라·프리뷰 RenderTexture는 Foundation unload 시 해제된다. 소품은 보존된 원본 hash, 실제 독립 검수 파일과 현재 import/runtime 증거로 BOM에 연결한다. 캐릭터·타이틀·아이콘·역사 텍스처의 미확인 서비스 경로와 검수는 별도 미완료 상태다.
