import { readFileSync } from 'node:fs'

export const publicationManifestSchema = JSON.parse(readFileSync(new URL('./publication-manifest.schema.json', import.meta.url), 'utf8'))
const compare = (left, right) => left < right ? -1 : left > right ? 1 : 0
const fail = (code, detail) => { throw new Error(`E_PUBLICATION_${code}:${detail}`) }

// This schema uses only the keywords checked here; it is not a general JSON Schema engine.
function assertShape(value, schema, location) {
  if (schema.$ref) return assertShape(value, publicationManifestSchema.$defs[schema.$ref.split('/').at(-1)], location)
  if ('const' in schema && value !== schema.const) fail('SHAPE', location)
  if (schema.enum && !schema.enum.includes(value)) fail('SHAPE', location)
  if (schema.type === 'string' && (typeof value !== 'string' || (schema.pattern && !new RegExp(schema.pattern).test(value)))) fail('SHAPE', location)
  if (schema.type === 'object') {
    if (!value || typeof value !== 'object' || Array.isArray(value)) fail('SHAPE', location)
    for (const key of schema.required) if (!Object.hasOwn(value, key)) fail('SHAPE', `${location}.${key}`)
    for (const key of Object.keys(value)) {
      if (!Object.hasOwn(schema.properties, key)) fail('FIELD', `${location}.${key}`)
      assertShape(value[key], schema.properties[key], `${location}.${key}`)
    }
  }
  if (schema.type === 'array') {
    if (!Array.isArray(value) || value.length < (schema.minItems ?? 0)) fail('SHAPE', location)
    if (schema.uniqueItems && new Set(value).size !== value.length) fail('DUPLICATE', location)
    value.forEach((item, index) => assertShape(item, schema.items, `${location}[${index}]`))
  }
}

function unique(values, name) {
  const seen = new Set()
  for (const value of values) {
    if (seen.has(value)) fail('DUPLICATE_' + name, value)
    seen.add(value)
  }
  return seen
}

const localPath = (value) => !value.startsWith('/') && !/[\\:#?\s]/u.test(value) && value.split('/').every((part) => part && part !== '.' && part !== '..')
const localRoute = (value) => value.startsWith('/') && !value.startsWith('//') && !/[\\#\s]/u.test(value) && !value.split(/[/?]/u).includes('..')
const identity = ({ source, id, route }) => JSON.stringify([source, id, route])

export function validatePublicationManifest(manifest, admittedDocuments) {
  assertShape(manifest, publicationManifestSchema, 'manifest')
  const categories = unique(manifest.categories.map(({ id }) => id), 'CATEGORY')
  unique(manifest.categories.map(({ route }) => route), 'CATEGORY_ROUTE')
  unique(manifest.documents.map(({ id }) => id), 'ID')
  unique(manifest.documents.map(({ route }) => route), 'ROUTE')
  unique(manifest.documents.map(({ contentRef }) => contentRef), 'CONTENT_REF')
  for (const category of manifest.categories) if (!localRoute(category.route)) fail('CATEGORY_ROUTE', category.route)
  for (const document of manifest.documents) {
    if (!localPath(document.source)) fail('SOURCE', document.source)
    if (!localPath(document.contentRef)) fail('CONTENT_REF', document.contentRef)
    if (!localRoute(document.route) || document.route.includes('?')) fail('ROUTE', document.route)
    for (const id of document.categoryIds) if (!categories.has(id)) fail('CATEGORY_UNKNOWN', `${document.id}:${id}`)
  }
  const admitted = unique(admittedDocuments.map(identity), 'ADMISSION')
  const actual = new Set(manifest.documents.map(identity))
  for (const value of actual) if (!admitted.has(value)) fail('SOURCE_UNPUBLISHED', value)
  for (const value of admitted) if (!actual.has(value)) fail('SOURCE_MISSING', value)
  for (const category of manifest.categories) {
    const expected = manifest.documents.filter(({ categoryIds }) => categoryIds.includes(category.id)).map(({ id }) => id)
    if (JSON.stringify(category.documentIds) !== JSON.stringify(expected)) fail('CATEGORY_INDEX', category.id)
  }
  return manifest
}

export function createPublicationManifest({ site, categories, documents, admittedDocuments }) {
  unique(documents.map(({ id }) => id), 'ID')
  const ordered = [...documents].sort((left, right) => compare(left.route, right.route))
  const manifest = {
    schemaVersion: 1,
    site,
    categories: categories.map(({ id, label, route }) => ({
      id, label, route,
      documentIds: ordered.filter(({ categoryIds }) => categoryIds.includes(id)).map((document) => document.id),
    })),
    documents: ordered.map(({ source, id, title, summary, categoryIds, route, contentRef }) => ({
      source, id, title, summary,
      categoryIds: [...categoryIds].sort((left, right) => categories.findIndex(({ id }) => id === left) - categories.findIndex(({ id }) => id === right)),
      route, contentRef,
    })),
  }
  return validatePublicationManifest(manifest, admittedDocuments)
}
